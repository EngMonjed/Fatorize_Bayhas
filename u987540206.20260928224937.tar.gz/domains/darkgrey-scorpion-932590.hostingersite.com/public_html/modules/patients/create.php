<?php
session_start();
require_once '../../config/database.php';

// تفعيل عرض الأخطاء للتطوير
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // التحقق من البيانات المدخلة
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $national_id = trim($_POST['national_id'] ?? '');
    $birth_date = trim($_POST['birth_date'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $emergency_phone = trim($_POST['emergency_phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    
    // تسجيل البيانات المدخلة
    error_log("Data received: " . print_r($_POST, true));
    
    // التحقق من صحة البيانات
    if (empty($first_name)) {
        $error = 'الاسم الأول مطلوب';
    } elseif (empty($last_name)) {
        $error = 'الاسم الأخير مطلوب';
    } elseif (empty($national_id)) {
        $error = 'الرقم الوطني مطلوب';
    } elseif (empty($birth_date)) {
        $error = 'تاريخ الميلاد مطلوب';
    } elseif (empty($gender) || !in_array($gender, ['ذكر', 'أنثى'])) {
        $error = 'الجنس مطلوب ويجب أن يكون ذكر أو أنثى';
    } elseif (empty($phone) || !preg_match('/^[0-9]{10}$/', $phone)) {
        $error = 'رقم الهاتف مطلوب ويجب أن يتكون من 10 أرقام';
    } elseif (!empty($emergency_phone) && !preg_match('/^[0-9]{10}$/', $emergency_phone)) {
        $error = 'رقم هاتف الطوارئ يجب أن يتكون من 10 أرقام';
    } else {
        try {
            // التحقق من عدم وجود مريض بنفس الرقم الوطني
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM patients WHERE national_id = ?");
            $stmt->execute([$national_id]);
            if ($stmt->fetchColumn() > 0) {
                $error = 'الرقم الوطني مسجل مسبقاً لمريض آخر';
            } else {
                // إضافة المريض
                $sql = "INSERT INTO patients (first_name, last_name, national_id, birth_date, gender, phone, emergency_phone, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                error_log("SQL Query: " . $sql);
                error_log("Parameters: " . print_r([$first_name, $last_name, $national_id, $birth_date, $gender, $phone, $emergency_phone, $address], true));
                
                $stmt = $pdo->prepare($sql);
                $result = $stmt->execute([$first_name, $last_name, $national_id, $birth_date, $gender, $phone, $emergency_phone, $address]);
                
                if ($result) {
                    $success = 'تم إضافة المريض بنجاح';
                    error_log("Patient added successfully");
                    // إعادة التوجيه إلى صفحة المرضى بعد ثانيتين
                    header("refresh:2;url=index.php");
                } else {
                    $error = 'فشل في إضافة المريض';
                    error_log("Failed to add patient");
                }
            }
        } catch(PDOException $e) {
            error_log("Database Error: " . $e->getMessage());
            error_log("Error Code: " . $e->getCode());
            error_log("SQL State: " . $e->errorInfo[0]);
            $error = 'حدث خطأ أثناء إضافة المريض: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة مريض جديد - نظام إدارة المستشفى</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
        }
        
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 1rem 0;
        }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: white !important;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .navbar-brand img {
            width: 40px;
            height: 40px;
            border-radius: 1px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            color: white !important;
            background-color: rgba(255,255,255,0.1);
        }
        
        .nav-link.active {
            background-color: rgba(255,255,255,0.2);
            color: white !important;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            margin-top: 2rem;
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 1rem;
        }
        
        .card-header h2 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .form-label {
            font-weight: 500;
            color: var(--primary-color);
        }
        
        .form-control {
            border-radius: 5px;
            border: 1px solid #ddd;
            padding: 0.5rem 1rem;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            padding: 0.5rem 2rem;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .alert {
            border-radius: 5px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../../index.php">
                <img src="../../assets/images/logo.png" alt="شعار المستشفى">
                مشفى الزرزور
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">
                            <i class="fas fa-users"></i> المرضى
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../appointments/index.php">
                            <i class="fas fa-calendar-check"></i> المواعيد
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../rooms/index.php">
                            <i class="fas fa-bed"></i> الغرف
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../employees/index.php">
                            <i class="fas fa-user-md"></i> الموظفين
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../accounting/index.php">
                            <i class="fas fa-calculator"></i> المحاسبة
                        </a>
                    </li>
                </ul>
                <div class="navbar-nav">
                    <a class="nav-link" href="../auth/logout.php">
                        <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2><i class="fas fa-user-plus"></i> إضافة مريض جديد</h2>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                        <br>
                        <a href="index.php" class="btn btn-primary mt-2">
                            <i class="fas fa-arrow-right"></i> العودة إلى قائمة المرضى
                        </a>
                    </div>
                <?php else: ?>
                    <form method="POST" class="needs-validation" novalidate>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="first_name" class="form-label">الاسم الأول</label>
                                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : ''; ?>" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="last_name" class="form-label">الاسم الأخير</label>
                                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : ''; ?>" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="national_id" class="form-label">الرقم الوطني</label>
                                <input type="text" class="form-control" id="national_id" name="national_id" value="<?php echo isset($_POST['national_id']) ? htmlspecialchars($_POST['national_id']) : ''; ?>" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="birth_date" class="form-label">تاريخ الميلاد</label>
                                <input type="date" class="form-control" id="birth_date" name="birth_date" value="<?php echo isset($_POST['birth_date']) ? htmlspecialchars($_POST['birth_date']) : ''; ?>" required>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="gender" class="form-label">الجنس</label>
                                <select class="form-select" id="gender" name="gender" required>
                                    <option value="">اختر الجنس</option>
                                    <option value="ذكر" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'ذكر' ? 'selected' : ''; ?>>ذكر</option>
                                    <option value="أنثى" <?php echo isset($_POST['gender']) && $_POST['gender'] == 'أنثى' ? 'selected' : ''; ?>>أنثى</option>
                                </select>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="phone" class="form-label">رقم الهاتف</label>
                                <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>" pattern="[0-9]{10}" title="يجب أن يتكون رقم الهاتف من 10 أرقام" required>
                                <div class="form-text">يجب أن يتكون رقم الهاتف من 10 أرقام</div>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="emergency_phone" class="form-label">رقم هاتف الطوارئ</label>
                                <input type="tel" class="form-control" id="emergency_phone" name="emergency_phone" value="<?php echo isset($_POST['emergency_phone']) ? htmlspecialchars($_POST['emergency_phone']) : ''; ?>" pattern="[0-9]{10}" title="يجب أن يتكون رقم الهاتف من 10 أرقام">
                                <div class="form-text">يجب أن يتكون رقم الهاتف من 10 أرقام</div>
                            </div>
                            
                            <div class="col-12">
                                <label for="address" class="form-label">العنوان</label>
                                <textarea class="form-control" id="address" name="address" rows="3" required><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?></textarea>
                            </div>
                            
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> حفظ البيانات
                                </button>
                                <a href="index.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-right"></i> العودة
                                </a>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // التحقق من صحة النموذج
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms).forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>
</body>
</html>