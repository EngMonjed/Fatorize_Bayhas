<?php
session_start();
require_once "../../config/database.php";
require_once "Patient.php";

// التحقق من تسجيل الدخول
if(!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// التحقق من وجود معرف المريض
if(!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

// إنشاء اتصال بقاعدة البيانات
$database = new Database();
$db = $database->getConnection();

// إنشاء كائن المريض
$patient = new Patient($db);

// تعيين معرف المريض
$patient->id = $_GET['id'];

// قراءة بيانات المريض
if($patient->readOne()) {
    // تم العثور على المريض
} else {
    // لم يتم العثور على المريض
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تفاصيل المريض - نظام إدارة المستشفى</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <?php include '../includes/navbar.php'; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title">تفاصيل المريض</h3>
                        <div>
                            <a href="edit.php?id=<?php echo $patient->id; ?>" class="btn btn-warning btn-sm">تعديل</a>
                            <a href="index.php" class="btn btn-secondary btn-sm">رجوع</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <h5>الاسم الأول</h5>
                                <p><?php echo $patient->first_name; ?></p>
                            </div>
                            <div class="col-md-6">
                                <h5>الاسم الأخير</h5>
                                <p><?php echo $patient->last_name; ?></p>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <h5>البريد الإلكتروني</h5>
                                <p><?php echo $patient->email ?: 'غير محدد'; ?></p>
                            </div>
                            <div class="col-md-6">
                                <h5>رقم الهاتف</h5>
                                <p><?php echo $patient->phone ?: 'غير محدد'; ?></p>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <h5>تاريخ الميلاد</h5>
                                <p><?php echo $patient->date_of_birth ?: 'غير محدد'; ?></p>
                            </div>
                            <div class="col-md-6">
                                <h5>الجنس</h5>
                                <p>
                                    <?php
                                    switch($patient->gender) {
                                        case 'male':
                                            echo 'ذكر';
                                            break;
                                        case 'female':
                                            echo 'أنثى';
                                            break;
                                        case 'other':
                                            echo 'أخرى';
                                            break;
                                        default:
                                            echo 'غير محدد';
                                    }
                                    ?>
                                </p>
                            </div>
                        </div>

                        <div class="mb-3">
                            <h5>العنوان</h5>
                            <p><?php echo $patient->address ?: 'غير محدد'; ?></p>
                        </div>

                        <div class="mb-3">
                            <h5>جهة اتصال للطوارئ</h5>
                            <p><?php echo $patient->emergency_contact ?: 'غير محدد'; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 