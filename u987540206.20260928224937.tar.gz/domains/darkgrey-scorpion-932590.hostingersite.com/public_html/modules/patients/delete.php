<?php
session_start();
require_once '../../config/database.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$error = '';
$success = '';

// التحقق من وجود معرف المريض
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = $_GET['id'];

// التحقق من وجود المريض
try {
    $stmt = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
    $stmt->execute([$id]);
    $patient = $stmt->fetch();
    
    if (!$patient) {
        header("Location: index.php");
        exit();
    }
} catch(PDOException $e) {
    error_log("Error checking patient: " . $e->getMessage());
    $error = "حدث خطأ أثناء التحقق من وجود المريض";
}

// معالجة حذف المريض
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // التحقق من عدم وجود مواعيد مرتبطة بالمريض
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE patient_id = ?");
        $stmt->execute([$id]);
        $appointmentCount = $stmt->fetchColumn();
        
        if ($appointmentCount > 0) {
            $error = "لا يمكن حذف المريض لأنه لديه مواعيد مرتبطة به";
        } else {
            // حذف المريض
            $stmt = $pdo->prepare("DELETE FROM patients WHERE id = ?");
            $stmt->execute([$id]);
            $success = "تم حذف المريض بنجاح";
            
            // إعادة التوجيه بعد ثانيتين
            header("refresh:2;url=index.php");
        }
    } catch(PDOException $e) {
        error_log("Error deleting patient: " . $e->getMessage());
        $error = "حدث خطأ أثناء حذف المريض";
    }
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حذف المريض - نظام إدارة المستشفى</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../../index.php">نظام إدارة المستشفى</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">المرضى</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../appointments/index.php">المواعيد</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../rooms/index.php">الغرف</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../employees/index.php">الموظفين</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../accounting/index.php">المحاسبة</a>
                    </li>
                </ul>
                <div class="navbar-nav">
                    <a class="nav-link" href="../auth/logout.php">تسجيل الخروج</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h2 class="mb-0">حذف المريض</h2>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                <?php echo $success; ?>
                                <br>
                                سيتم إعادة توجيهك إلى قائمة المرضى...
                            </div>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                هل أنت متأكد من حذف المريض التالي؟
                                <br>
                                <strong>اسم المريض:</strong> <?php echo htmlspecialchars($patient['name']); ?>
                            </div>
                            
                            <form method="POST" action="">
                                <div class="d-flex justify-content-between">
                                    <a href="index.php" class="btn btn-secondary">إلغاء</a>
                                    <button type="submit" class="btn btn-danger">حذف المريض</button>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 