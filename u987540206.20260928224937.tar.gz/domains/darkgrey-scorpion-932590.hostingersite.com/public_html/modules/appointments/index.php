<?php
session_start();
require_once '../../config/database.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit();
}

// معالجة تغيير حالة الموعد
if (isset($_POST['update_status'])) {
    $appointment_id = $_POST['appointment_id'] ?? '';
    $new_status = $_POST['new_status'] ?? '';
    
    if (!empty($appointment_id) && !empty($new_status)) {
        try {
            $stmt = $pdo->prepare("UPDATE appointments SET status = ? WHERE id = ?");
            $stmt->execute([$new_status, $appointment_id]);
            $success = 'تم تحديث حالة الموعد بنجاح';
        } catch(PDOException $e) {
            $error = 'حدث خطأ أثناء تحديث حالة الموعد';
        }
    }
}


// جلب قائمة المواعيد
try {
    // التحقق من وجود الجداول أولاً
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $required_tables = ['doctors', 'patients', 'appointments'];
    $missing_tables = array_diff($required_tables, $tables);
    
    if (!empty($missing_tables)) {
        $error = 'الجداول التالية غير موجودة: ' . implode(', ', $missing_tables);
    } else {
        $stmt = $pdo->query("
            SELECT 
                a.id,
                a.appointment_date,
                a.appointment_time,
                a.status,
                a.reason,
                CONCAT(p.first_name, ' ', p.last_name) as patient_name,
                CONCAT(d.first_name, ' ', d.last_name) as doctor_name
            FROM appointments a
            JOIN patients p ON a.patient_id = p.id
            JOIN doctors d ON a.doctor_id = d.id
            ORDER BY a.appointment_date DESC, a.appointment_time DESC
        ");
        $appointments = $stmt->fetchAll();
        
        if (empty($appointments)) {
            $error = 'لا توجد مواعيد مسجلة بعد';
        }
    }
} catch(PDOException $e) {
    error_log("خطأ في قاعدة البيانات: " . $e->getMessage());
    $error = 'حدث خطأ في جلب قائمة المواعيد: ' . $e->getMessage();
}
// تحويل حالة الموعد إلى العربية
function getStatusInArabic($status) {
    $statusMap = [
        'pending' => 'قيد الانتظار',
        'confirmed' => 'مؤكد',
        'cancelled' => 'ملغي',
        'completed' => 'مكتمل'
    ];
    return $statusMap[$status] ?? $status;
}
// تحويل التاريخ إلى التنسيق العربي
function formatDate($date) {
    $months = [
        'January' => 'يناير',
        'February' => 'فبراير',
        'March' => 'مارس',
        'April' => 'أبريل',
        'May' => 'مايو',
        'June' => 'يونيو',
        'July' => 'يوليو',
        'August' => 'أغسطس',
        'September' => 'سبتمبر',
        'October' => 'أكتوبر',
        'November' => 'نوفمبر',
        'December' => 'ديسمبر'
    ];
    
    $formatted = date('d F Y', strtotime($date));
    foreach ($months as $en => $ar) {
        $formatted = str_replace($en, $ar, $formatted);
    }
    return $formatted;
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المواعيد - نظام إدارة المستشفى</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
        }
        
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 1rem 0;
        }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: white !important;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .navbar-brand img {
            width: 40px;
            height: 40px;
            border-radius: 1px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            color: white !important;
            background-color: rgba(255,255,255,0.1);
        }
        
        .nav-link.active {
            background-color: rgba(255,255,255,0.2);
            color: white !important;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .table {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
            border: none;
        }
        
        .table td {
            vertical-align: middle;
        }
        
        .btn-action {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
            margin: 0 0.25rem;
        }
        .badge {
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 500;
            font-size: 0.85rem;
        }
        .form-select {
            padding: 0.375rem 2.25rem 0.375rem 0.75rem;
            font-size: 0.9rem;
            border-radius: 5px;
            border: 1px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-select:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .alert {
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            border: none;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 0;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: #dee2e6;
            margin-bottom: 1rem;
        }
        
        .empty-state p {
            color: #6c757d;
            font-size: 1.1rem;
            margin: 0;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../../index.php">
                <img src="https://srv1244-files.hstgr.io/3f5b14b11612fceb/files/public_html/assets/logos/logo.png" alt="شعار المستشفى">
                مشفى الزرزور
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../patients/index.php">
                            <i class="fas fa-users"></i> المرضى
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../doctors/index.php">
                            <i class="fas fa-user-md"></i> الأطباء
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="../appointments/index.php">
                            <i class="fas fa-calendar-check"></i> المواعيد
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../rooms/index.php">
                            <i class="fas fa-bed"></i> الغرف
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../employees/index.php">
                            <i class="fas fa-user-md"></i> الموظفين
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../accounting/index.php">
                            <i class="fas fa-calculator"></i> المحاسبة
                        </a>
                    </li>
                </ul>
                <div class="navbar-nav">
                    <a class="nav-link" href="../auth/logout.php">
                        <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">
                        <i class="fas fa-calendar-check"></i>
                        إدارة المواعيد
                    </h4>
                    <a href="create.php" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>
                        حجز موعد جديد
                    </a>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                            <th>#</th>
                                <th>التاريخ</th>
                                <th>الوقت</th>
                                <th>المريض</th>
                                <th>الطبيب</th>
                                <th>سبب الزيارة</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (!empty($appointments)): ?>
                        <?php foreach ($appointments as $index => $appointment): ?>
                            <tr>
                            <td><?php echo $index + 1; ?></td>
                                        <td><?php echo formatDate($appointment['appointment_date']); ?></td>
                                        <td><?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></td>
                                        <td><?php echo htmlspecialchars($appointment['patient_name']); ?></td>
                                        <td><?php echo htmlspecialchars($appointment['doctor_name']); ?></td>
                                        <td><?php echo htmlspecialchars($appointment['reason']); ?></td>
                                        <td>
                                        <span class="badge bg-<?php 
                                                echo match($appointment['status']) {
                                                    'pending' => 'warning',
                                                    'confirmed' => 'success',
                                                    'cancelled' => 'danger',
                                                    'completed' => 'info',
                                                    default => 'secondary'
                                                };
                                            ?>">
                                                <?php echo getStatusInArabic($appointment['status']); ?>
                                            </span>
                                </td>
                                <td>
                                <div class="btn-group" role="group">
                                                <a href="edit.php?id=<?php echo $appointment['id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form method="POST" class="d-inline" onsubmit="return confirm('هل أنت متأكد من حذف هذا الموعد؟');">
                                                    <input type="hidden" name="appointment_id" value="<?php echo $appointment['id']; ?>">
                                                    <input type="hidden" name="delete_appointment" value="1">
                                                    <button type="submit" class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="appointment_id" value="<?php echo $appointment['id']; ?>">
                                                    <select name="new_status" class="form-select form-select-sm d-inline-block" style="width: auto;" onchange="this.form.submit()">
                                                        <option value="">تغيير الحالة</option>
                                                        <option value="pending" <?php echo $appointment['status'] == 'pending' ? 'selected' : ''; ?>>قيد الانتظار</option>
                                                        <option value="confirmed" <?php echo $appointment['status'] == 'confirmed' ? 'selected' : ''; ?>>مؤكد</option>
                                                        <option value="cancelled" <?php echo $appointment['status'] == 'cancelled' ? 'selected' : ''; ?>>ملغي</option>
                                                        <option value="completed" <?php echo $appointment['status'] == 'completed' ? 'selected' : ''; ?>>مكتمل</option>
                                                    </select>
                                                    <input type="hidden" name="update_status" value="1">
                                                </form>
                                            </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                                                       <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">
                                        <div class="empty-state">
                                            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                                            <p class="text-muted">لا توجد مواعيد مسجلة حالياً</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 