<?php
session_start();
require_once '../../config/database.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit();
}

// حذف طبيب
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM doctors WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: index.php');
    exit();
}

// تحديد عمود الترتيب والاتجاه
$order_column = isset($_GET['order']) ? $_GET['order'] : 'created_at';
$order_direction = isset($_GET['direction']) ? $_GET['direction'] : 'DESC';

// التحقق من صحة عمود الترتيب
$allowed_columns = ['id', 'first_name', 'last_name', 'specialization', 'department', 'status', 'created_at'];
if (!in_array($order_column, $allowed_columns)) {
    $order_column = 'created_at';
}

// التحقق من صحة اتجاه الترتيب
if (!in_array(strtoupper($order_direction), ['ASC', 'DESC'])) {
    $order_direction = 'DESC';
}

// جلب قائمة الأطباء مع الترتيب
$stmt = $pdo->query("SELECT * FROM doctors ORDER BY $order_column $order_direction");
$doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);

// دالة لتغيير اتجاه الترتيب
function getOrderDirection($current_column, $current_direction) {
    if ($current_column === $_GET['order'] ?? '') {
        return $current_direction === 'ASC' ? 'DESC' : 'ASC';
    }
    return 'ASC';
}

// دالة لتحديد أيقونة الترتيب
function getSortIcon($column, $current_order, $current_direction) {
    if ($column === $current_order) {
        return $current_direction === 'ASC' ? '↑' : '↓';
    }
    return '↕';
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الأطباء - نظام إدارة المستشفى</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
        }
        
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 1rem 0;
        }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: white !important;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .navbar-brand img {
            width: 40px;
            height: 40px;
            border-radius: 1px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            color: white !important;
            background-color: rgba(255,255,255,0.1);
        }
        
        .nav-link.active {
            background-color: rgba(255,255,255,0.2);
            color: white !important;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .table {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
            border: none;
            cursor: pointer;
            user-select: none;
        }
        
        .table th:hover {
            background-color: var(--secondary-color);
        }
        
        .table td {
            vertical-align: middle;
        }
        
        .btn-action {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
            margin: 0 0.25rem;
        }
        
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
        }
        
        .status-active {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-inactive {
            background-color: #f8d7da;
            color: #721c24;
        }

        .sort-icon {
            margin-right: 5px;
            font-size: 0.8em;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../../index.php">
                <img src="../../assets/images/logo.png" alt="شعار المستشفى">
                مشفى الزرزور
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../patients/index.php">
                            <i class="fas fa-users"></i> المرضى
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="../doctors/index.php">
                            <i class="fas fa-user-md"></i> الأطباء
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../appointments/index.php">
                            <i class="fas fa-calendar-check"></i> المواعيد
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../rooms/index.php">
                            <i class="fas fa-bed"></i> الغرف
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../employees/index.php">
                            <i class="fas fa-user-md"></i> الموظفين
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../accounting/index.php">
                            <i class="fas fa-calculator"></i> المحاسبة
                        </a>
                    </li>
                </ul>
                <div class="navbar-nav">
                    <a class="nav-link" href="../auth/logout.php">
                        <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">
                        <i class="fas fa-user-md text-primary me-2"></i>
                        إدارة الأطباء
                    </h4>
                    <a href="create.php" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>
                        إضافة طبيب جديد
                    </a>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>
                                    <a href="?order=id&direction=<?php echo getOrderDirection('id', $order_direction); ?>" class="text-white text-decoration-none">
                                        # <span class="sort-icon"><?php echo getSortIcon('id', $order_column, $order_direction); ?></span>
                                    </a>
                                </th>
                                <th>
                                    <a href="?order=first_name&direction=<?php echo getOrderDirection('first_name', $order_direction); ?>" class="text-white text-decoration-none">
                                        الاسم <span class="sort-icon"><?php echo getSortIcon('first_name', $order_column, $order_direction); ?></span>
                                    </a>
                                </th>
                                <th>
                                    <a href="?order=specialization&direction=<?php echo getOrderDirection('specialization', $order_direction); ?>" class="text-white text-decoration-none">
                                        التخصص <span class="sort-icon"><?php echo getSortIcon('specialization', $order_column, $order_direction); ?></span>
                                    </a>
                                </th>
                                <th>
                                    <a href="?order=department&direction=<?php echo getOrderDirection('department', $order_direction); ?>" class="text-white text-decoration-none">
                                        القسم <span class="sort-icon"><?php echo getSortIcon('department', $order_column, $order_direction); ?></span>
                                    </a>
                                </th>
                                <th>الممرض المساعد</th>
                                <th>
                                    <a href="?order=status&direction=<?php echo getOrderDirection('status', $order_direction); ?>" class="text-white text-decoration-none">
                                        الحالة <span class="sort-icon"><?php echo getSortIcon('status', $order_column, $order_direction); ?></span>
                                    </a>
                                </th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($doctors as $doctor): ?>
                            <tr>
                                <td><?php echo $doctor['id']; ?></td>
                                <td><?php echo htmlspecialchars($doctor['first_name'] . ' ' . $doctor['last_name']); ?></td>
                                <td><?php echo htmlspecialchars($doctor['specialization']); ?></td>
                                <td><?php echo htmlspecialchars($doctor['department']); ?></td>
                                <td><?php echo htmlspecialchars($doctor['assistant_nurse']); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $doctor['status'] === 'active' ? 'status-active' : 'status-inactive'; ?>">
                                        <?php echo $doctor['status'] === 'active' ? 'نشط' : 'غير نشط'; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="view.php?id=<?php echo $doctor['id']; ?>" class="btn btn-info btn-action">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="edit.php?id=<?php echo $doctor['id']; ?>" class="btn btn-warning btn-action">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="index.php?delete=<?php echo $doctor['id']; ?>" class="btn btn-danger btn-action" onclick="return confirm('هل أنت متأكد من حذف هذا الطبيب؟')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 