<?php
session_start();
require_once '../../config/database.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit();
}

// التحقق من وجود معرف الطبيب
if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit();
}

$id = $_GET['id'];

// جلب بيانات الطبيب
$stmt = $pdo->prepare("SELECT * FROM doctors WHERE id = ?");
$stmt->execute([$id]);
$doctor = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$doctor) {
    header('Location: index.php');
    exit();
}

// جلب عدد المواعيد للطبيب
$stmt = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id = ?");
$stmt->execute([$id]);
$appointments_count = $stmt->fetchColumn();

// جلب عدد الحالات التي يتعامل معها الطبيب
$stmt = $pdo->prepare("SELECT COUNT(*) FROM admissions WHERE doctor_id = ?");
$stmt->execute([$id]);
$admissions_count = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تفاصيل الطبيب - نظام إدارة المستشفى</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
        }
        
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 1rem 0;
        }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: white !important;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .navbar-brand img {
            width: 40px;
            height: 40px;
            border-radius: 1px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            color: white !important;
            background-color: rgba(255,255,255,0.1);
        }
        
        .nav-link.active {
            background-color: rgba(255,255,255,0.2);
            color: white !important;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .doctor-info {
            background-color: white;
            border-radius: 10px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        
        .info-label {
            color: var(--primary-color);
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        
        .info-value {
            font-size: 1.1rem;
            margin-bottom: 1rem;
        }
        
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
        }
        
        .status-active {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-inactive {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .stats-card {
            text-align: center;
            padding: 1.5rem;
            border-radius: 10px;
            background-color: white;
            margin-bottom: 1rem;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--secondary-color);
        }
        
        .stats-label {
            color: #6c757d;
            margin-top: 0.5rem;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="../../index.php">
                <img src="../../assets/images/logo.png" alt="شعار المستشفى">
                مشفى الزرزور
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../patients/index.php">
                            <i class="fas fa-users"></i> المرضى
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="../doctors/index.php">
                            <i class="fas fa-user-md"></i> الأطباء
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../appointments/index.php">
                            <i class="fas fa-calendar-check"></i> المواعيد
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../rooms/index.php">
                            <i class="fas fa-bed"></i> الغرف
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../employees/index.php">
                            <i class="fas fa-user-md"></i> الموظفين
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../accounting/index.php">
                            <i class="fas fa-calculator"></i> المحاسبة
                        </a>
                    </li>
                </ul>
                <div class="navbar-nav">
                    <a class="nav-link" href="../auth/logout.php">
                        <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="mb-0">
                        <i class="fas fa-user-md text-primary me-2"></i>
                        تفاصيل الطبيب
                    </h4>
                    <div>
                        <a href="edit.php?id=<?php echo $doctor['id']; ?>" class="btn btn-warning me-2">
                            <i class="fas fa-edit me-2"></i>
                            تعديل البيانات
                        </a>
                        <a href="index.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-right me-2"></i>
                            العودة للقائمة
                        </a>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="stats-card">
                            <div class="stats-number"><?php echo $appointments_count; ?></div>
                            <div class="stats-label">المواعيد</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stats-card">
                            <div class="stats-number"><?php echo $admissions_count; ?></div>
                            <div class="stats-label">الحالات</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stats-card">
                            <div class="stats-number">
                                <span class="status-badge <?php echo $doctor['status'] === 'active' ? 'status-active' : 'status-inactive'; ?>">
                                    <?php echo $doctor['status'] === 'active' ? 'نشط' : 'غير نشط'; ?>
                                </span>
                            </div>
                            <div class="stats-label">الحالة</div>
                        </div>
                    </div>
                </div>

                <div class="doctor-info">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-label">الاسم الكامل</div>
                            <div class="info-value"><?php echo htmlspecialchars($doctor['first_name'] . ' ' . $doctor['last_name']); ?></div>
                                              
                            <div class="info-label">رقم الهاتف</div>
                            <div class="info-value"><?php echo htmlspecialchars($doctor['phone']); ?></div>
                            
                            <div class="info-label">البريد الإلكتروني</div>
                            <div class="info-value"><?php echo htmlspecialchars($doctor['email']); ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-label">التخصص</div>
                            <div class="info-value"><?php echo htmlspecialchars($doctor['specialization']); ?></div>
                            
                            <div class="info-label">القسم</div>
                            <div class="info-value"><?php echo htmlspecialchars($doctor['department']); ?></div>
                            
                            <div class="info-label">الممرض المساعد</div>
                            <div class="info-value"><?php echo htmlspecialchars($doctor['assistant_nurse']); ?></div>
                            
                            <div class="info-label">تاريخ التسجيل</div>
                            <div class="info-value"><?php echo date('Y-m-d', strtotime($doctor['created_at'])); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 