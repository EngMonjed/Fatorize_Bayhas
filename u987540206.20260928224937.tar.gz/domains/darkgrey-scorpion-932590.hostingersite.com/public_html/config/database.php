<?php
// معلومات الاتصال بقاعدة البيانات
$host = 'localhost';
$dbname = 'u987540206_hospital_manag';
$username = 'u987540206_Monjed';
$password = 'Ss123+%&';

try {
    // إنشاء اتصال PDO
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    // التحقق من الاتصال
    $pdo->query("SELECT 1");
    //echo "تم الاتصال بقاعدة البيانات بنجاح";
    
} catch(PDOException $e) {
    // تسجيل الخطأ في ملف السجل وعرضه
    $error_message = "خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage();
    error_log($error_message);
    echo "<pre>";
    echo $error_message;
    echo "</pre>";
    die();
}
?> 