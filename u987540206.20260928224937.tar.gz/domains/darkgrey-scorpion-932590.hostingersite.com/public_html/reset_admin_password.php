<?php
require_once 'config/database.php';

try {
    // توليد كلمة مرور مشفرة جديدة
    $password = 'admin123';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // تحديث كلمة المرور للمستخدم admin
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE username = ?");
    $stmt->execute([$hashed_password, 'admin']);
    
    echo "<div dir='rtl'>";
    echo "<h2>تم إعادة تعيين كلمة المرور بنجاح!</h2>";
    echo "<p>اسم المستخدم: admin</p>";
    echo "<p>كلمة المرور الجديدة: admin123</p>";
    echo "</div>";
    
} catch(PDOException $e) {
    echo "<div dir='rtl'>";
    echo "<p style='color: red;'>خطأ: " . $e->getMessage() . "</p>";
    echo "</div>";
}
?> 