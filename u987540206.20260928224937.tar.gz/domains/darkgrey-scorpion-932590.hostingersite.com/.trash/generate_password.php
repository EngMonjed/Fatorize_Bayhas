<?php
$password = 'admin123';
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
echo "كلمة المرور المشفرة: " . $hashed_password;

// التحقق من صحة التشفير
if(password_verify($password, $hashed_password)) {
    echo "\nتم التحقق من صحة التشفير بنجاح!";
} else {
    echo "\nفشل التحقق من صحة التشفير!";
}
?> 