<?php
require_once 'config/database.php';

try {
    // توليد كلمة مرور مشفرة
    $password = 'admin123';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // حذف المستخدم القديم
    $stmt = $pdo->prepare("DELETE FROM users WHERE username = ?");
    $stmt->execute(['admin']);
    
    // إضافة المستخدم الجديد مع كلمة المرور المشفرة
    $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    $stmt->execute(['admin', $hashed_password, 'admin']);
    
    echo "<h2>تم إعادة تعيين كلمة المرور بنجاح!</h2>";
    echo "<p>اسم المستخدم: admin</p>";
    echo "<p>كلمة المرور: admin123</p>";
    echo "<p>كلمة المرور المشفرة: " . $hashed_password . "</p>";
    
    // التحقق من وجود المستخدم
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute(['admin']);
    $user = $stmt->fetch();
    
    if ($user) {
        echo "<h3>تم التحقق من وجود المستخدم:</h3>";
        echo "<pre>";
        print_r($user);
        echo "</pre>";
        
        // التحقق من صحة كلمة المرور
        if (password_verify($password, $user['password'])) {
            echo "<p style='color: green;'>تم التحقق من صحة كلمة المرور بنجاح!</p>";
        } else {
            echo "<p style='color: red;'>فشل التحقق من صحة كلمة المرور!</p>";
        }
    } else {
        echo "<p style='color: red;'>لم يتم العثور على المستخدم!</p>";
    }
    
} catch(PDOException $e) {
    echo "<p style='color: red;'>خطأ: " . $e->getMessage() . "</p>";
}
?> 