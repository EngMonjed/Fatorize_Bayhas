<?php
require_once 'config/database.php';

try {
    // التحقق من وجود جدول المستخدمين
    $stmt = $pdo->query("SELECT * FROM users");
    $users = $stmt->fetchAll();
    
    echo "<h2>نتائج الاختبار:</h2>";
    echo "<p>تم الاتصال بقاعدة البيانات بنجاح!</p>";
    echo "<p>عدد المستخدمين في قاعدة البيانات: " . count($users) . "</p>";
    
    if (count($users) > 0) {
        echo "<h3>المستخدمون الحاليون:</h3>";
        echo "<ul>";
        foreach ($users as $user) {
            echo "<li>اسم المستخدم: " . htmlspecialchars($user['username']) . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>لا يوجد مستخدمون في قاعدة البيانات!</p>";
    }
    
} catch(PDOException $e) {
    echo "<p style='color: red;'>خطأ: " . $e->getMessage() . "</p>";
}
?> 