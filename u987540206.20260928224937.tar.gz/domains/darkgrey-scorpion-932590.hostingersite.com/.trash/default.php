<?php
session_start();
require_once 'config/database.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: modules/auth/login.php");
    exit();
}

// جلب إحصائيات النظام
try {
    // عدد المرضى
    $stmt = $pdo->query("SELECT COUNT(*) FROM patients");
    $patients_count = $stmt->fetchColumn();
    
    // عدد المواعيد اليوم
    $stmt = $pdo->query("SELECT COUNT(*) FROM appointments WHERE DATE(appointment_date) = CURDATE()");
    $today_appointments = $stmt->fetchColumn();
    
    // عدد الغرف المشغولة
    $stmt = $pdo->query("SELECT COUNT(*) FROM rooms WHERE status = 'مشغولة'");
    $occupied_rooms = $stmt->fetchColumn();
    
    // عدد الموظفين
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'employee'");
    $employees_count = $stmt->fetchColumn();

    // عدد الأطباء
    $stmt = $pdo->query("SELECT COUNT(*) FROM doctors WHERE status = 'active'");
    $doctors_count = $stmt->fetchColumn();
} catch(PDOException $e) {
    error_log("Error fetching statistics: " . $e->getMessage());
    // تعيين قيم افتراضية في حالة حدوث خطأ
    $patients_count = 0;
    $today_appointments = 0;
    $occupied_rooms = 0;
    $employees_count = 0;
    $doctors_count = 0;
}
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الصفحة الرئيسية - نظام إدارة المستشفى</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
        }
        
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f8f9fa;
        }
        
        .navbar {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)) !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding: 1rem 0;
        }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: white !important;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .navbar-brand img {
            width: 40px;
            height: 40px;
            border-radius: 1px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 500;
            padding: 0.5rem 1rem !important;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            color: white !important;
            background-color: rgba(255,255,255,0.1);
        }
        
        .nav-link.active {
            background-color: rgba(255,255,255,0.2);
            color: white !important;
        }
        
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--secondary-color);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .stat-label {
            color: #6c757d;
            font-size: 1.1rem;
        }
        
        .welcome-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 2rem;
            border-radius: 10px;
            margin-bottom: 2rem;
        }
        
        .welcome-section h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        
        .welcome-section p {
            font-size: 1.2rem;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/images/logo.png" alt="شعار المستشفى">
                مشفى الزرزور
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="modules/patients/index.php">
                            <i class="fas fa-users"></i> المرضى
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="modules/doctors/index.php">
                            <i class="fas fa-user-md"></i> الأطباء
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="modules/appointments/index.php">
                            <i class="fas fa-calendar-check"></i> المواعيد
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="modules/rooms/index.php">
                            <i class="fas fa-bed"></i> الغرف
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="modules/employees/index.php">
                            <i class="fas fa-user-md"></i> الموظفين
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="modules/accounting/index.php">
                            <i class="fas fa-calculator"></i> المحاسبة
                        </a>
                    </li>
                </ul>
                <div class="navbar-nav">
                    <a class="nav-link" href="modules/auth/logout.php">
                        <i class="fas fa-sign-out-alt"></i> تسجيل الخروج
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="welcome-section">
            <h1>
                <i class="fas fa-hospital"></i> مرحباً بك في نظام إدارة المستشفى
            </h1>
            <p>نظام متكامل لإدارة جميع عمليات المستشفى بكفاءة عالية</p>
        </div>

        <div class="row g-4">
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-users stat-icon"></i>
                        <div class="stat-number"><?php echo $patients_count; ?></div>
                        <div class="stat-label">المرضى المسجلين</div>
                        <a href="modules/patients/index.php" class="btn btn-primary mt-3">
                            <i class="fas fa-arrow-left"></i> عرض التفاصيل
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-calendar-check stat-icon"></i>
                        <div class="stat-number"><?php echo $today_appointments; ?></div>
                        <div class="stat-label">مواعيد اليوم</div>
                        <a href="modules/appointments/index.php" class="btn btn-primary mt-3">
                            <i class="fas fa-arrow-left"></i> عرض التفاصيل
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-bed stat-icon"></i>
                        <div class="stat-number"><?php echo $occupied_rooms; ?></div>
                        <div class="stat-label">الغرف المشغولة</div>
                        <a href="modules/rooms/index.php" class="btn btn-primary mt-3">
                            <i class="fas fa-arrow-left"></i> عرض التفاصيل
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-user-md stat-icon"></i>
                        <div class="stat-number"><?php echo $employees_count; ?></div>
                        <div class="stat-label">الموظفين</div>
                        <a href="modules/employees/index.php" class="btn btn-primary mt-3">
                            <i class="fas fa-arrow-left"></i> عرض التفاصيل
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="fas fa-user-md stat-icon"></i>
                        <div class="stat-number"><?php echo $doctors_count; ?></div>
                        <div class="stat-label">الأطباء النشطين</div>
                        <a href="modules/doctors/index.php" class="btn btn-primary mt-3">
                            <i class="fas fa-arrow-left"></i> عرض التفاصيل
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 