<?php
require_once 'config/database.php';

try {
    // التحقق من محتوى جدول المستخدمين
    $stmt = $pdo->query("SELECT * FROM users");
    $users = $stmt->fetchAll();
    
    echo "<h2>محتوى جدول المستخدمين:</h2>";
    echo "<pre>";
    print_r($users);
    echo "</pre>";
    
    // التحقق من هيكل الجدول
    $stmt = $pdo->query("DESCRIBE users");
    $columns = $stmt->fetchAll();
    
    echo "<h2>هيكل جدول المستخدمين:</h2>";
    echo "<pre>";
    print_r($columns);
    echo "</pre>";
    
} catch(PDOException $e) {
    echo "<p style='color: red;'>خطأ: " . $e->getMessage() . "</p>";
}
?> 