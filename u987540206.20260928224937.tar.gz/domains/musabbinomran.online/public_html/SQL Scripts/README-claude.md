# FATORIZE — Multi-Branch, Multi-Tenant Financial & Inventory ERP

A native-PHP, no-framework ERP system, originally built for **Bayhas** (a
clothing retail/manufacturing company) and now being generalized into a
**multi-tenant SaaS product**. It covers sales, purchases, inventory,
accounting (chart of accounts, journal entries, receipts), HR/payroll,
consumables, and inter-branch internal orders.

> **Documentation basis:** this document is maintained incrementally across
> our working sessions. Every structural claim below (folder names, table
> names, constants) has been verified directly against the actual PHP/SQL
> files as they exist **right now**, after the July 2026 renaming
> migration described in [Migration Log](#migration-log-july-2026--generic-branchtenant-naming).
> Anything not yet re-verified after that migration is explicitly flagged
> "⚠ not yet re-verified".

---

## Table of Contents

1. [Migration Log (July 2026 — generic branch/tenant naming)](#migration-log-july-2026--generic-branchtenant-naming)
2. [Currency Architecture (July 2026 — reporting currency reform)](#currency-architecture-july-2026--reporting-currency-reform)
3. [Sidebar/Menu Restructuring & Shared Components (July 2026)](#sidebarmenu-restructuring--shared-components-july-2026)
4. [Project Description & Purpose](#project-description--purpose)
5. [Technologies Used](#technologies-used)
6. [Folder / File Structure](#folder--file-structure)
7. [The BASE_PATH Constant](#the-base_path-constant)
8. [Deployment Environments](#deployment-environments)
9. [System Architecture](#system-architecture)
10. [Multi-Branch Model](#multi-branch-model)
11. [Multi-Tenant SaaS Architecture](#multi-tenant-saas-architecture)
12. [Database Overview](#database-overview)
13. [Authentication & Authorization](#authentication--authorization)
14. [Application Workflow](#application-workflow)
15. [Features](#features)
16. [Barcode Module](#barcode-module-generation--scanning)
17. [Purchase Invoice Currency-Mismatch Bug (fixed)](#purchase-invoice-currency-mismatch-bug-fixed)
18. [Consumables Module Findings](#consumables-module-findings--النتيجة-النهائية-قسم-مكتمل-بالكامل)
19. [Inventory & Products Module Findings (in progress)](#inventory--products-module-findings--تقدّم-الجلسة-الحالية-غير-مكتمل)
20. [Security Notes](#security-notes)
21. [Known Limitations](#known-limitations)
22. [Future Improvements](#future-improvements)
23. [Troubleshooting](#troubleshooting)
24. [Development Guidelines](#development-guidelines)

---

## Migration Log (July 2026 — generic branch/tenant naming)

بهالجلسة عملنا سلسلة تعديلات لإزالة أي تسمية مرتبطة بمكان/عميل محدد
(Aleppo, Bayhas) من بنية النظام نفسها، تحضيراً لتحويله لمنتج SaaS عام.
هاي خلاصة كل شي اتغيّر، بالترتيب:

| # | التغيير | من | إلى | الحالة |
|---|---|---|---|---|
| 1 | لاحقة جداول قاعدة البيانات لفرع البيع الأول (٥٤ جدول) | `_alp` | `_ret` | ✅ منفّذ (`01_migrate_alp_to_ret.sql`) |
| 2 | اسم/نوع الفرع الأول بجدول `branches` | "فرع حلب"، `branch_type` متنوع | "فرع البيع ١"، `branch_type='retail'` | ✅ منفّذ |
| 3 | قيم `branches.branch_type` الممكنة | `retail/factory/warehouse/lab/office` | `retail/factory` فقط (ENUM مقيّد بقاعدة البيانات) | ✅ منفّذ |
| 4 | مجلد كود الفرع الأول | `aleppo/` | `retail1/` | ✅ منفّذ (فيزيائياً + بكل مراجع الكود) |
| 5 | مجلد جذر المشروع | `bayhas/` | `fatorize_erp_system/` | ✅ منفّذ **على نسخة اللوكل (Laragon) فقط** — نسخة Hostinger لسا ما انرينمت (انظر [بيئات النشر](#deployment-environments)) |
| 6 | مسارات مطلقة مكتوبة حرفياً بكل الكود (`/bayhas/...`) | سترينغ ثابت متكرر بعشرات الأماكن | ثابت مركزي واحد `BASE_PATH` | ✅ منفّذ (انظر [The BASE_PATH Constant](#the-base_path-constant)) |
| 7 | `config/create_branch_tables.php` — مراجع القالب المرجعي لأي فرع جديد | `SELECT * FROM sales_invoices_alp WHERE 0` وأخواتها (١٢ جدول) | نفس الاستعلامات لكن `_ret` | ✅ منفّذ |
| 8 | اسم قاعدة البيانات الفعلية بـ MySQL | `u987540206_bayhas` | (لم يتغيّر) | 🟡 قرار واعٍ: ما في داعي وظيفي لترينيمها — "الاسم المنطقي" المستقبلي (`tenant1` أو مشابه) رح يصير قيمة بعمود `subdomain` بجدول `tenants` المستقبلي فقط، مو اسم الـ DB الفعلي |
| 9 | محتوى `about.php` التسويقي (قصة بايهاس كعميل حقيقي أول) | — | (لم يتغيّر) | 🟢 مقصود — محتوى تسويقي حقيقي، مش جزء من منطق الـ tenant |

### ملفات الترحيل المُنتجة بهالجلسة (سجل مرجعي)
- `01_migrate_alp_to_ret.sql` — رينيم الـ ٥٤ جدول + تحديث صف الفرع + تقييد enum
- `02_rollback_ret_to_alp.sql` — سكريبت عكس احتياطي (غير مُستخدم)
- `03_update_dashboard_path.sql` — تحديث `branches.dashboard_path` بعد رينيم `aleppo→retail1` ثم `bayhas→fatorize_erp_system`
- `dashboard.php`, `sidebar.php`, `branches.php`, `create_branch_tables.php`, `purchases/index.php` — محدّثين ومرفوعين

### ⚠ نقطة مفتوحة يجب تتبعها
جرد يدوي كامل عبر VS Code ("Find in Files") عن `/bayhas/` تم على **نسخة
اللوكل (Laragon)** وأُعلن الانتهاء منه بالكامل. **نسخة Hostinger
(`F:\Programming\kaylink\FatoRize\bayhas\`) لسا بالحالة القديمة بالكامل**
— لسا فيها `config/database.php` بالنسخة البسيطة (اتصال DB ثابت، بدون
`tenant_resolver.php`)، ولسا مجلداتها `bayhas/` و`aleppo/` وجداولها `_alp`
لسا متل ما كانت. **لا تفترض تطابق البيئتين لحد ما تُعاد نفس خطوات
الترحيل كاملة على نسخة Hostinger.**

---

## Currency Architecture (July 2026 — reporting currency reform)

بجلسة منفصلة (بعد جلسة الترحيل البنيوي أعلاه) اكتشفنا وصلحنا Anti-pattern
حقيقي: كل عمود مالي بقاعدة بيانات كل tenant كان مسمّى صراحة بلاحقة
`_usd` — يعني اسم العمود نفسه كان مقفول على افتراض "العملة المرجعية
دايماً دولار"، رغم إنه المفروض تكون قابلة للاختيار من كل شركة عميلة.

### النموذج الصحيح المعتمد الآن (مطابق لـ IAS 21)

نظام العملات صار بمستويين منفصلين تماماً، كل وحد مجمّد بلحظة إنشائه ولا
يتغيّر بعدها كإعداد روتيني:

| المستوى | الاسم المحاسبي | وين يُختار | وين يُخزَّن | يشمل |
|---|---|---|---|---|
| **الشركة كاملة** | Reporting/Group Currency (عملة التقارير) | وقت تسجيل الشركة (tenant جديد) | `fatorize_master.tenants.reporting_currency_id` (FK) | كل فروع نفس الشركة — موحّدة إجبارياً بينهم، عشان مقارنة التكلفة بين الفروع تصير ممكنة |
| **كل فرع لحاله** | Functional Currency (العملة الوظيفية) | وقت إنشاء الفرع | `branches.base_currency` (varchar(3)، داخل قاعدة الـ tenant نفسها) | فرع واحد بس — منفصل تماماً عن عملة التقارير، ما بينلمس بهالإصلاح |

**الفرق الجوهري بينهم:** عملة التقارير هي "لغة المقارنة" المشتركة بين
كل فروع الشركة (مهما كانت عملتها الوظيفية الفعلية)؛ العملة الوظيفية هي
العملة يلي الفرع فعلياً بيشتغل/بيسعّر فيها يومياً. **الاثنين مجمّدان بعد
أول تحديد** — تغييرهم لاحقاً كإعداد عادي غير مسموح (فرق عن سعر الصرف
اليومي، يلي بيتغيّر بشكل طبيعي عبر جدول `currencies`/`exchange_rates_{TS}`).

### قاعدة `fatorize_master` — التنفيذ

- جدول جديد `currencies` (مصغّر، **بدون أسعار صرف** — مجرد قاموس هوية
  عملة: `id`, `code`, `name`, `symbol`)، معبّى بـ٦ عملات شائعة بالمنطقة
- عمود `tenants.reporting_currency_id` — FK حقيقي لهالجدول، `NOT NULL`
- تينانت Bayhas الحالي اتعبّى تلقائياً على `USD` (مطابق للافتراض الضمني
  الموجود سابقاً بكل تسميات `_usd`)
- **Trigger فعلي بقاعدة البيانات** (`trg_tenants_freeze_reporting_currency`)
  بيمنع أي `UPDATE` يغيّر القيمة بعد أول تحديد — تجميد حقيقي بمستوى الـDB
  نفسها، مو بس اتفاق ضمني بالتطبيق
- السكريبت: `09_master_reporting_currency.sql`

### قاعدة كل tenant — إعادة تسمية الأعمدة

**الصيغة المعتمدة:** `_usd` → `_base` (مثال: `unit_price_usd` →
`unit_price_base`). **٢٣ عمود بـ١٥ جدول** بقاعدة `bayhas_local` (السكريبت:
`10_rename_usd_to_base_columns.sql`، **✅ منفّذ ومؤكّد من المستخدم**):

`consumable_issue_items_ret`, `consumable_items_ret`,
`consumable_movements_ret`, `consumable_purchases_ret` (٦ أعمدة),
`consumable_purchase_items_ret`, `consumable_stock_ret`, `expenses_ret`,
`internal_order_items`, `inventory_movements_ret`, `payroll_ret` (الجدول
الميت القديم، غير `hr_payroll_ret`), `production_entries_ret`,
`production_operations_ret`, `raw_material_stock_ret`, `receipts_ret`,
`sales_invoice_items_ret`.

**تعليقات مضلّلة إضافية اتصلحت** (بدون رينيم — أسماء الأعمدة كانت أصلاً
عامة، بس التوصيف مكتوب "USD" صراحة): `branches.base_currency`،
`currencies.exchange_rate`/`is_base`، `inventory_movement_details_ret.cost_price`،
`receipt_invoices_ret.allocated_amount`، `sales_invoices_ret.cost_total`
+ تعليق الجدول نفسه، `sales_invoice_items_ret.unit_price`.

### ملفات PHP — الجرد الكامل والإصلاحات (١٦ ملف، ✅ كلهم منتهين)

بعد رينيم الأعمدة، كل ملف PHP بيستعلم/يكتب لهالأعمدة كان لازم يتفحص
ويتحدّث. الجرد تم عبر VS Code "Find in Files" عن `_usd` بكامل المشروع:

| الملف | شو صار |
|---|---|
| `config/create_branch_tables.php` | ✅ (من جلسة الترحيل البنيوي — القالب المرجعي) |
| `api/confirm_purchase_invoice.php` | ✅ رينيم + **٣ إصلاحات hardcoded `'USD'`** بقيود الدفعة المقدمة/الشحن/الدفع → عملة الفرع الفعلية أو عملة المعاملة الحقيقية |
| `api/confirm_sale_invoice.php` | ✅ رينيم + hardcoded `'USD'` بقيد COGS. ⚠ تضارب منطقي بحساب `original_amount` بقيد ذمم العملاء — **موثّق بالكود، لم يُصلح** (نفس فئة تضارب اتجاه سعر الصرف الموثّق سابقاً، يحتاج قرار محاسبي منفصل) |
| `api/payroll_api.php` | ✅ رينيم + **🔴 بق حرج**: استعلام `base_currency_id` (عمود غير موجود بـ`branches`، الاسم الحقيقي `base_currency` نصي) كان يفشل بخطأ SQL — **حساب وصرف الرواتب كانا معطّلين بالكامل**. أُصلح بـJOIN حقيقي لجدول `currencies` |
| `accounting/receipts.php` | ✅ رينيم + **🔴 بق `_alp` منفصل تماماً** (`account_charts_alp` حرفياً بدالة `getSettingAccount()` — بقايا ترحيل قديمة نجت من كل الفحوصات السابقة لأنها جوا نص SQL مش مسار) — كانت **كل عملية سند قبض فيها قيد محاسبي تفشل بالكامل** |
| `accounting/expenses.php` | ✅ رينيم بحت — صفر بق |
| `inventory/consumable_issues.php` | ✅ رينيم + hardcoded `'USD'` بقيد الصرف + فلترة مستودعات بالنوع + `$currentModule` كانت بمفتاح غلط |
| `inventory/consumable_purchases.php` (الأكبر، ٢١٤٣ سطر) | ✅ ١١ عمود + ١١ متغير PHP + `$currentModule` **غير معرّفة إطلاقاً** + hardcoded `'USD'` بـ٥ أماكن (ترحيل + إلغاء عكسي) |
| `inventory/consumables.php` | ✅ رينيم بحت (`avg_cost_usd`) |
| `inventory/internal_orders.php` | ✅ رينيم + **🔴 بقّان حرجان**: `final_amount_usd`/`unit_price_usd` بجدولي `purchases_ret`/`purchase_items_ret` — **أسماء غير موجودة إطلاقاً** (الاسم الحقيقي `_base_currency`، نفس فئة بق `confirm_purchase_invoice.php` بالضبط) — **تحويل أي طلب داخلي لفاتورة شراء كان يفشل بالكامل** |
| `inventory/movements.php` | ✅ رينيم أعمدة حقيقية (`consumable_movements_ret`) + أسماء مستعارة PHP |
| `sales/customers.php`, `sales/sales_index.php` | ✅ أسماء مستعارة PHP فقط (`total_amount`/`balance_amount` أصلاً عامة) |
| `sales/sales_invoice_new.php` | ✅ عمود حقيقي وحيد (`cost_price_usd`) |
| `purchases/invoice_new.php`, `purchases/invoice_edit.php` | ✅ **لا بق** — السيرفر كان أصلاً يستخدم `unit_price_base_currency` الصحيح؛ الـ`_usd` كانت بس تسمية متغيرات JS بالمتصفح |

### اكتشاف مهم: نمطين مختلفين من "الاسم الصحيح" بنفس المشروع

بعض الجداول (`purchases_ret.final_amount_base_currency`,
`purchase_items_ret.unit_price_base_currency`) **كانت أصلاً مسمّاة صح
من البداية** (`_base_currency`، مش `_usd`) — المشكلة فيها كانت كود بأماكن
تانية (`confirm_purchase_invoice.php`, `internal_orders.php`) بيستخدم
اسم **مختلف وغير موجود** (`_usd`) بدل الاسم الحقيقي، فيفشل الاستعلام
بصمت أو بخطأ SQL. **هاي بقّات كتابة/قراءة لعمود غلط، مش تسميات تحتاج
توحيد** — كانت موجودة *قبل* إصلاح اليوم، ومكتشفة بالصدفة أثناء الفحص.

### 🟢 مؤجّل بقرار واعٍ (مو نسيان)

- **مفتاح `'cash_usd'`** بجدول `invoice_account_settings_{TS}` (يستخدمه
  `payroll_api.php` و`receipts.php`) — **تأكّد من المستخدم إنه مقصود
  فعلاً**: يمثّل حساب صندوق نقدي مخصص للدولار تحديداً بشجرة الحسابات
  (الشركة ممكن يكون عندها أكتر من صندوق بعملات مختلفة) — **لن يُغيَّر**.
- **توحيد رمز العملة بالواجهة** — `$` مكتوبة حرفياً بعشرات الأماكن
  (`dashboard.php` وغيره)، وفحوصات JS من نوع `=== 'USD'` (مثل
  `onExpCurrChange()` بـ`expenses.php`، `isUSD` بعدة ملفات) — طبقة واجهة
  متكاملة تستاهل جلسة تصليح مخصصة موحّدة، مش تصليح متجزّئ ملف-ملف.
- **فجوة سعر صرف الشحن** بـ`confirm_purchase_invoice.php` — لا يوجد حقل
  لسعر صرف مستقل لتكلفة الشحن؛ لو أُدخلت بعملة غير عملة الفرع، ما في
  تحويل حقيقي (rate=1 مفترض). ميزة مستقبلية، مش إصلاح تسمية.
- **تضارب اتجاه سعر الصرف** بقيد ذمم العملاء (`confirm_sale_invoice.php`)
  — موثّق بالكود، ينتظر قرار محاسبي منفصل.

### ⚠ لسا مفتوح

**جرد `_alp` شامل عبر كل المشروع** (`grep -rn "_alp"`، مش `/bayhas/`
ولا `_usd`) — بما إنه اكتُشفت وحدة حقيقية بـ`receipts.php` كانت خفية
عن كل الفحوصات السابقة (جوا نص SQL، مش مسار ملف)، فيه احتمال حقيقي
لوجود نظائر بملفات تانية ما فُحصت بعد لهالغرض تحديداً.

**✅ تحديث: أُغلق هالبند.** جرد شامل عبر VS Code ("Find in Files") عن
`_alp` بكامل المشروع — **صفر نتائج**. لا حاجة لمتابعته أكتر.

---

## Sidebar/Menu Restructuring & Shared Components (July 2026)

جلسة ثالثة (بعد الترحيل البنيوي وإصلاح العملات) ركّزت على إعادة تنظيم
الشريط الجانبي فعلياً — منطقياً (أي قسم بيحوي شو) وفيزيائياً (مجلدات
الملفات الحقيقية)، مع اكتشاف كام بق حقيقي بالطريق.

### إعادة الهيكلة المنطقية لجدول `modules`

| التغيير | الحالة |
|---|---|
| نقل "إدارة المستهلكات" ومشتقاتها من "المخزون" لمجموعة جديدة "المصاريف والمستهلكات" | ✅ (`07_restructure_modules_menu.sql`) |
| نقل "مشتريات المستهلكات" لمجموعة "المشتريات" (مطابقة لمعيار Odoo/SAP: كل الشراء تحت Purchasing بغض النظر عن نوع الصنف) | ✅ — بعد تصحيح إضافي (`12_fix_consumable_purchases_parent.sql`) لأنه أول تشغيل كان ترك القيمة القديمة `expenses` بالغلط |
| حذف مجموعة "العملاء والموردون" (CRM) بالكامل | ✅ (`11_dissolve_crm_group.sql`) — العملاء انضموا لـ"المبيعات"، الموردون بقوا بمكانهم الوحيد أصلاً تحت "المشتريات" (كانوا مكررين بمكانين) |
| إضافة "فاتورة شراء جديدة" (`purchases.invoices.new`) | ✅ (`13_add_purchases_invoice_new.sql`) — لم تكن موجودة إطلاقاً بالتصميم الأصلي، مش شي انحذف |

**الهيكلية النهائية:**

| المبيعات | المشتريات | المخزون | المصاريف والمستهلكات |
|---|---|---|---|
| فواتير البيع | إدارة الموردين | المنتجات | إدارة المستهلكات |
| فاتورة بيع جديدة | فاتورة شراء جديدة | الطلبات الداخلية | مشتريات المستهلكات* |
| العملاء (نُقلت من CRM) | مشتريات المنتجات | المستودعات (منتجات) | أمر صرف استهلاكي |
| | | حركات المخزون (منتجات) | مستودعات المستهلكات |
| | | | حركة المستهلكات |
| | | | إدارة المصاريف |

*"مشتريات المستهلكات" فعلياً تحت مجموعة "المشتريات" بجدول `modules`؛ الجدول هون بيعرضها جنب أخواتها بالمصاريف والمستهلكات للسياق البصري بس.

### إعادة الهيكلة الفيزيائية — مجلد جديد `modules/expenses_and_consumables/`

الملفات الأربعة الحصرية لقسم المصاريف والمستهلكات انتقلت فيزيائياً:
`consumables.php`, `consumable_purchases.php`, `consumable_issues.php`
(من `inventory/`)، و`expenses.php` (من `accounting/`).

**`warehouse.php` و`movements.php` بقوا بمكانهم تحت `inventory/`** —
مشتركين بين قسمين (منتجات/مستهلكات عبر `?type=`/`?tab=`)، النقل كان
رح يكسر قسم "المخزون".

**دُوّن نمط خطر أثناء النقل:** أي رابط نسبي داخل ملف منقول يشاور على
ملف بقي بمكانه القديم لازم ياخذ `../` إضافية (والعكس: رابط لملف انتقل
معه لنفس المجلد الجديد لازم تُشال منه الـ`../`). **صار خطأ فعلي أكتر من
مرة** أثناء التنفيذ — نسخة مرفوعة من `consumables.php` كان فيها ٤ روابط
مكسورة بالكامل بعد النقل (تبويبات `warehouse.php`/`movements.php`/
`expenses.php` + رابط تفصيلي لمستودعات) لأنها لسا بمساراتها القديمة.
**قاعدة عملية:** بعد أي نقل مجلد، دوّر يدوياً عن كل `href=` داخل الملفات
المنقولة وتأكد من كل مسار نسبي.

### مكوّن جديد: `includes/breadcrumb.php`

Breadcrumb عام لأي صفحة موديول "قياسية" (قسم ثابت واحد) — بيقرأ نفس
`$menu`/`$currentModule` الجاهزين أصلاً من `sidebar.php`، صفر بيانات
إضافية لكل صفحة:
```php
require_once __DIR__ . '/../../includes/breadcrumb.php';
// وبالـ<header>:
<?= renderBreadcrumb() ?>
```
**استثناء مقصود:** الصفحات "مزدوجة الغرض" (`warehouse.php`, `movements.php`)
ما بتستخدمه — عندها Breadcrumb يدوي خاص بيبدّل القسم المعروض ديناميكياً
حسب `?type=`/`?tab=` النشط بنفس الصفحة (مو قسم ثابت واحد).

طُبّق `renderBreadcrumb()` على الملفات الأربعة المنقولة. ملاحظة مفيدة:
بعض الـ Breadcrumb القديمة اليدوية كانت **غلط فعلياً** (مش بس تجميلية) —
مثلاً `consumable_purchases.php` كانت بتربط نفسها بـ"المستهلكات" رغم
إنها هلق منطقياً تحت "المشتريات"؛ استبدالها بالمكوّن الديناميكي صحّح
هالخطأ تلقائياً بدون أي تعديل يدوي إضافي.

### 🔴 بق مكتشف: دوال JS الشريط الجانبي (`toggleGroup`/`sbOpen`/`sbClose`) مفقودة من بعض الصفحات

كل صفحة موديول بتتضمن نسخة خاصة فيها من هالثلاث دوال (نسخ-لصق بالآخر،
مش ملف مشترك). `warehouse.php` تحديداً كانت ناقصة منها بالكامل —
النتيجة: الضغط على أي عنوان قسم رئيسي بالشريط الجانبي (Accordion) ما
كان يعمل أي شي **وهو بهالصفحة تحديداً بس**، حتى بعد تحديث الصفحة (لأنه
المشكلة سطر كود ناقص، مش حالة محفوظة). **أُصلحت بـ`warehouse.php`.**

**⚠ لسا مفتوح:** باقي صفحات المشروع (حسب تشجير `modules/` الكامل — تقريباً
٢٤ ملف) لسا ما انفحصت لنفس البق. **القرار المتفق عليه:** الفحص بيصير
تدريجياً مع كل قسم بيتراجع بمحادثة منفصلة (المستهلكات/المصاريف خلص ✅ —
باقي الستة ملفات فيها كلها، ما فيها مشكلة)، مش جرد شامل دفعة وحدة.
**قرار استخراج الدوال لملف JS مشترك واحد (بدل التكرار بكل صفحة) — لسا
معلّق، ينتظر قرار.**

### إصلاح `admin/branches.php` — تجميد العملة الوظيفية للفرع

أثناء مراجعة الصفحة (تعديل فرع موجود — **لا يوجد بها ولا بأي مكان تاني
بالمشروع مسار "إنشاء فرع جديد" فعلياً**؛ الفروع تُنشأ حالياً يدوياً
عبر SQL مباشر، فجوة موثّقة أدناه)، اكتُشفت وأُصلحت ٤ مشاكل مع بعض:

| # | المشكلة | الحل |
|---|---|---|
| ١ | 🔴 الفورم بيبعت `base_currency_id`/`local_currency_id` — أعمدة **غير موجودة إطلاقاً** بجدول `branches` (نفس فئة بق `payroll_api.php` المكتشف بجلسة العملات) — **كانت تُسقط حفظ أي إعداد فرع بالكامل** | أُزيلا نهائياً، الأعمدة الحقيقية `base_currency`/`local_currency` فقط |
| ٢ | 🔴 قيمة `<select>` رقم ID، بينما العمود الحقيقي نصي (كود عملة) | صارت قيمة الخيارات كود العملة مباشرة |
| ٣ | 🟡 تسمية "العملة الأساسية (**التقارير**)" — تناقض مباشر مع نموذج العملتين الموثّق أعلاه (عملة التقارير على مستوى الشركة، مو الفرع) | "العملة **الوظيفية** للفرع (Functional Currency)" |
| ٤ | تجميد العملة الوظيفية بعد الإنشاء (قرار IAS 21 سابق، ما كان مُطبَّق) | الحقل `disabled` بالواجهة **+ رفض صريح بالسيرفر** لو حدا حاول يتخطاه من devtools |

العملة المحلية (`local_currency`، عملة المعاملات اليومية) بقيت قابلة
للتعديل عادي — التجميد بالقرار الأصلي كان بس على العملة الوظيفية.

### ⚠ لسا مفتوح

- **صفحة "إضافة فرع جديد"** غير موجودة إطلاقاً — مؤجّلة لمحادثة الإدارة والصلاحيات
- **تعميم `renderBreadcrumb()`** على باقي صفحات النظام (طُبّق بس على قسم المصاريف والمستهلكات لحد الآن)
- **استخراج JS الشريط الجانبي لملف مشترك** — قرار معلّق
- **فجوة `consumable_issues.php`:** لا يوجد ربط بجدول `consumable_item_packagings_ret` (عبوات/عامل تحويل) عند اختيار مادة الصرف — نفس الميزة موجودة ومفعّلة بـ`consumable_purchases.php`. مؤجّلة لمحادثة المستهلكات المخصصة
- **حقل "الجهة المستلمة"** بـ`consumable_issues.php` — تأكيد توثيقي (مش بق): نص حر باقتراحات PHP ثابتة (`$DEPT_SUGGESTIONS`)، بدون ربط فعلي بأي جدول (لا `branches`، لا جدول أقسام) — تصميم مقصود
- **مزامنة نسخة Hostinger** — مؤجّلة بقرار واعٍ لحد اكتمال التطوير المحلي بالكامل، بعدها جلسة مستقلة كاملة

---

## Project Description & Purpose

**FATORIZE** هو ERP بُني أصلاً لشركة **بايهاس** (تصنيع/بيع ألبسة)، وعم
يتحوّل حالياً لمنتج **SaaS متعدد المستأجرين (multi-tenant)** يُباع لعدة
شركات مستقلة بقطاع الألبسة بالمنطقة العربية. النموذج المخطط:

- **قاعدة بيانات منفصلة لكل عميل (tenant)** — مو مشتركة.
- **نفس نسخة الكود بالضبط** مشتركة بين كل العملاء (لا يوجد مجلد منفصل
  لكل عميل — التمييز يصير عبر الساب-دومين وتحليل `tenant_resolver.php`).
- **داخل كل قاعدة بيانات عميل**، الموديل القديم (فروع متعددة بلاحقة
  اسم جدول، `_ret` مثلاً) باقٍ زي ما هو — هو المستوى الأدنى غير المتأثر
  بالـ SaaS pivot.
- **نوع الفرع الآن مقيّد بقيمتين فقط:** فرع بيع (`retail`) أو فرع
  تصنيع (`factory`) — لا أسماء جغرافية، لا أنواع تانية (مستودع/مختبر/مكتب
  أُزيلت من الواجهة والـ enum).

كل فرع بيع/تصنيع (بغض النظر عن التسمية القديمة) بيغطي: فوترة بيع/شراء،
مخزون متعدد المستودعات، محاسبة كاملة، HR/رواتب، مستهلكات، طلبات داخلية
بين الفروع، وصلاحيات دقيقة لكل مستخدم/فرع/موديول.

---

## Technologies Used

| Layer | Technology |
|---|---|
| Backend language | PHP (native, procedural, PHP 7.4+/8.x) |
| Database | MySQL/MariaDB via PDO + prepared statements |
| Frontend markup | HTML5, rendered inline by PHP |
| CSS | Custom `layout.css` + Bootstrap 5.3 RTL (CDN) + inline `<style>` blocks؛ + `marketing.css` منفصل للصفحات التسويقية العامة |
| JavaScript | Vanilla JS inline + `attendance_patch.js` |
| Password hashing | `password_hash()`/`password_verify()` (bcrypt) |
| Session | PHP native sessions |
| Data exchange | Server-rendered HTML + fetch/XHR AJAX بنمط موحّد `_action` |

لا فريمورك، لا ORM، لا Composer، لا build step.

---

## Folder / File Structure

> ⚠ التشجير تحت بيعكس نسخة **اللوكل (Laragon)** الحالية فقط، بعد
> الترحيل الكامل. نسخة Hostinger لسا بالبنية القديمة (`bayhas/aleppo/...`)
> — انظر [بيئات النشر](#deployment-environments).

```
fatorize_erp_system/                  (جذر المشروع — كان اسمه bayhas/)
├── login.php
├── logout.php
├── select_account.php
├── reset_password.php                ⚠ لسا موجود، لازم يُحذف قبل أي إنتاج حقيقي
├── index.php                         الصفحة الرئيسية التسويقية (SaaS landing)
├── about.php                         صفحة "من نحن" التسويقية
├── find-my-company.php               بحث عن تينانت بالساب-دومين (SaaS)
│
├── config/
│   ├── database.php                  ⚠ نسختان مختلفتان بين البيئتين — انظر أدناه
│   ├── auth.php
│   ├── create_branch_tables.php      ✅ محدّث: القالب المرجعي بيستنسخ من _ret الآن
│   ├── master_database.php           (SaaS) اتصال قاعدة بيانات المنصة المركزية
│   └── tenant_resolver.php           (SaaS) تحليل الساب-دومين → أي DB يتصل فيها
│
├── includes/
│   ├── sidebar.php                   ✅ محدّث: BASE_PATH + retail1 بدل aleppo
│   └── product_save_helper.php
│
├── assets/
│   ├── css/ (layout.css, marketing.css)
│   └── images/ (logo.png, fatorize.png, bayhas_logo.png — شعار طباعة حقيقي، لم يُمس)
│
├── retail1/                           فرع البيع الأول (كان aleppo/، لاحقة الجداول ret)
│   ├── assets/
│   ├── api/
│   │   ├── confirm_sale_invoice.php
│   │   ├── confirm_purchase_invoice.php
│   │   ├── payroll_api.php
│   │   ├── get_currencies.php
│   │   └── test_api.php
│   └── modules/
│       ├── dashboard.php             ✅ محدّث: يتحقق من table_suffix==='ret'، BASE_PATH
│       ├── sales/
│       ├── purchases/                ✅ index.php محدّث (LOGO_URL بيستخدم BASE_PATH)
│       ├── inventory/
│       │   └── barcode.php
│       ├── accounting/
│       │   └── branches.php ⚠ (تأكد المسار — راجع admin/ أدناه، النسخة الأخيرة محدّثة: retail/factory بس)
│       ├── hr/
│       └── admin/
│           ├── users.php
│           ├── permissions.php
│           └── branches.php          ✅ محدّث: branchTypes = retail/factory فقط
│
└── logs/
    └── php-error.log
```

**فروع تانية (Istanbul, Gaziantep, labs):** schema-only، ما عندها كود
حقيقي بعد — خريطة `sidebar.php::moduleUrl()` لسا محتفظة بمداخل مرجعية
إلها (`ist`, `gaz`, `lab`, `alp_lab`) لحد ما يتبنى هيكل عام حقيقي لفرع
تصنيع/بيع إضافي، بس مو مستخدمة فعلياً حالياً.

---

## The BASE_PATH Constant

أُضيف بهالجلسة كنقطة تحكم مركزية وحيدة لمسار جذر التطبيق، بدل عشرات
المسارات المطلقة المكتوبة حرفياً (`/bayhas/...`) يلي كانت متناثرة بكل
الكود.

```php
// أول سطر بـ config/database.php (بعد التعليق التوضيحي، قبل أي شي تاني)
if (!defined('BASE_PATH')) define('BASE_PATH', '/fatorize_erp_system');
```

**كل مكان بالكود كان فيه مسار مطلق حرفي**، صار يستخدمها بدل السترينغ
الثابت:

```php
// قبل
header('Location: /bayhas/select_account.php');
<img src="/bayhas/assets/images/logo.png">
$base = '/bayhas/' . $branchFolder . '/modules/';

// بعد
header('Location: ' . BASE_PATH . '/select_account.php');
<img src="<?= BASE_PATH ?>/assets/images/logo.png">
$base = BASE_PATH . '/' . $branchFolder . '/modules/';
```

**قيمتها تختلف حسب البيئة والانتشار المستقبلي:**

| السياق | القيمة |
|---|---|
| نسخة اللوكل حالياً (Laragon، `http://localhost/fatorize_erp_system/...`) | `/fatorize_erp_system` |
| نسخة Hostinger حالياً (لسا ما انرينمت، `/bayhas/...`) | `/bayhas` (لسا ما اتحدثت فعلياً) |
| لو استُخدم دومين وهمي محلي (`fatorize.test` بدل `localhost/...`) | `''` (فاضي) |
| النشر الفعلي المستقبلي بساب-دومين لكل عميل (`tenant1.fatorize.com`) | `''` (فاضي) — كل ساب-دومين بيوصل لجذر الكود مباشرة |

**ملفات ما زالت محتاجة تدقيق يدوي على نسخة Hostinger تحديداً** (لأنه
الجرد اليدوي عبر VS Code تم على نسخة اللوكل بس): أي ملف فيه `/bayhas/`
حرفياً — نفس منهجية البحث والاستبدال المستخدمة سابقاً على اللوكل.

---

## Deployment Environments

| | نسخة اللوكل (Laragon) | نسخة Hostinger (إنتاج) |
|---|---|---|
| المسار الفيزيائي | `D:\laragon\www\fatorize_erp_system\` | `F:\Programming\kaylink\FatoRize\bayhas\` ⚠ لسا باسمها القديم |
| رابط الوصول | `http://localhost/fatorize_erp_system/...` | (دومين حقيقي — غير موثّق هون) |
| `config/database.php` | **نسخة SaaS**: `tenant_resolver.php` مفعّل، الاتصال بـ DB يتحدد ديناميكياً من الساب-دومين | **نسخة بسيطة قديمة**: اتصال ثابت مباشر بـ `u987540206_bayhas` عبر `define('DB_NAME', ...)` — ما فيها `tenant_resolver.php` إطلاقاً |
| لاحقة جداول الفرع الأول | `_ret` ✅ | `_alp` ⚠ لسا ما اترحّلت |
| مجلد الفرع الأول | `retail1/` ✅ | `aleppo/` ⚠ لسا |
| مجلد الجذر | `fatorize_erp_system/` ✅ | `bayhas/` ⚠ لسا |
| `BASE_PATH` | معرّف، `/fatorize_erp_system` ✅ | غير موجود إطلاقاً بهالنسخة ⚠ |

**هاد فرق جوهري ومقصود مؤقتاً** — عم نجرّب كل الترحيل والبنية الجديدة
(retail/factory، BASE_PATH، SaaS resolver) على اللوكل أول، وبعدين ننزلها
دفعة وحدة عالـ Hostinger لما نتأكد كل شي شغال صح. **لا تفترض أي سلوك أو
بنية موحّدة بين البيئتين لحد ما يُذكر خلاف ذلك بتحديث لاحق لهالتوثيق.**

---

## System Architecture

نفس البنية الأصلية — كل ملف PHP هو controller + view بنفس الوقت، لا
MVC، لا فصل طبقات. النمط القياسي لأي صفحة موديول:

```php
session_start();
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../config/auth.php';
$pdo = getConnection();
checkLogin($pdo);
requirePermission('module.key', 'view');
$TS = $_SESSION['table_suffix'];       // الآن "ret" لفرع البيع الأول
$table = "products_{$TS}";
```

---

## Multi-Branch Model

| Concept | Detail |
|---|---|
| قاعدة بيانات كل تينانت | واحدة، مشتركة بين كل فروعه |
| عزل البيانات بين الفروع | لاحقة اسم جدول (`table_suffix`) |
| نوع الفرع | `branch_type` ENUM مقيّد الآن لـ `retail`/`factory` فقط |
| مفاتيح الجلسة | `table_suffix`, `branch_id`, `branch_name`, `dashboard_path` |
| توفير فرع جديد | `config/create_branch_tables.php::createBranchTables()` — القالب المرجعي بيستنسخ بنية `_ret` الآن (بعد الإصلاح) |

| الفرع | `table_suffix` | مجلد الكود | الحالة |
|---|---|---|---|
| فرع البيع ١ (كان "حلب") | `ret` | `retail1/` | ✅ الوحيد اللي عنده كود حقيقي شغّال |
| باقي الفروع (Istanbul, Gaziantep, labs) | `ist`/`gaz`/`lab`/`alp_lab` | مرجعية بـ `sidebar.php` فقط | Schema-only، بدون كود |

`dashboard.php` يتحقق حالياً من `table_suffix === 'ret'` بشكل ثابت
(نفس نمط الفحص القديم `=== 'alp'`، بس بالقيمة الجديدة) — **لسا نقطة
ضعف معمارية** لو صار فرع بيع تاني بالمستقبل، لازم يصير الفحص على
`branch_type === 'retail'` بدل قيمة `table_suffix` ثابتة (موثّق أيضاً
بـ [Known Limitations](#known-limitations)).

---

## Multi-Tenant SaaS Architecture

**الحالة: الطبقة التأسيسية مبنية ومفعّلة فعلياً على نسخة اللوكل، غير
منزّلة على نسخة الإنتاج (Hostinger) بعد.**

### القرارات
| القرار | الاختيار |
|---|---|
| عزل البيانات | قاعدة بيانات منفصلة كاملة لكل تينانت |
| تمييز التينانت | ساب-دومين (`tenant1.fatorize.com`) |
| موديل الفروع/الجداول داخل كل تينانت | غير متأثر — نفس الـ `table_suffix` |
| اسم قاعدة البيانات الفعلي (تينانت بايهاس الحالي) | باقٍ `u987540206_bayhas` — الاسم المنطقي المستقبلي (`tenant1` مثلاً) بيصير بعمود `subdomain` بجدول `tenants` بس، مو اسم الـ DB نفسه |

### ما هو موجود فعلياً الآن
- `config/master_database.php` — اتصال قاعدة بيانات المنصة المركزية
- `config/tenant_resolver.php` — `resolveCurrentTenant()`
- `config/database.php` (نسخة اللوكل) — `getConnection()` بيحلّ التينانت أول من الساب-دومين، بعدين يتصل بقاعدته
- `find-my-company.php`, `index.php`, `about.php` — صفحات تسويقية عامة، لا تتصل بقاعدة بيانات تينانت معيّن

### ⚠ لسا غير مفعّل/موثّق بالكامل
- نسخة Hostinger (الإنتاج) لسا على النسخة القديمة single-DB، غير موصولة بـ `tenant_resolver.php` إطلاقاً
- ما تم اختبار تسجيل دخول فعلي عبر ساب-دومين حقيقي بعد (الاختبار الحالي كله عبر `localhost` بدون ساب-دومين)
- `super_admin/add_tenant.php` (موثّق بجلسات سابقة) لم يُعاد التحقق منه بعد هالترحيل

---

## Database Overview

**قاعدة البيانات (تينانت بايهاس الحالي):** `u987540206_bayhas` (الاسم لم
يتغيّر — انظر [Migration Log](#migration-log-july-2026--generic-branchtenant-naming) نقطة ٨).

### جداول عامة (بدون لاحقة) — لم تتأثر بالترحيل
`users`, `user_branches`, `user_permissions`, `user_activities`,
`branches`, `modules`, `currencies`, `shipping_carriers`,
`internal_orders`, `internal_order_items`

### جداول الفرع الأول — لاحقتها الآن `_ret` (كانت `_alp`)
نفس الـ ٥٤ جدول الموثّقة سابقاً (منتجات، مخزون، مبيعات، مشتريات،
محاسبة، مستهلكات، HR، تصنيع، إشعارات) — القائمة الكاملة موجودة بملف
`01_migrate_alp_to_ret.sql` كمرجع دقيق لكل اسم جدول قبل/بعد.

> **الجداول القديمة الميتة** (`employees_alp`→`employees_ret`,
> `attendance_alp`→`attendance_ret`, `payroll_alp`→`payroll_ret`,
> `consumables_alp`→`consumables_ret`, `consumable_entries_alp`→
> `consumable_entries_ret`) **اترحّلت هي كمان** لنفس لاحقة `_ret` رغم
> إنها ميتة (الكود الفعلي بيستخدم النسخ `hr_*`)، حفاظاً على الاتساق —
> بس لسا ميتة وظيفياً، وما زالت مرشّحة للحذف لاحقاً.

---

## Authentication & Authorization

لم يتغيّر أي شي هون بهالجلسة — `config/auth.php` وكل دوال RBAC
(`checkLogin`, `loadUserPermissions`, `can`, `requirePermission`,
`buildSidebarMenu`) زي ما هي تماماً. راجع التوثيق الأصلي لتفاصيل تدفق
تسجيل الدخول.

---

## Application Workflow

لم تتأثر منطقياً بالترحيل — دورة حياة فاتورة البيع والشراء زي ما هي
(تأكيد كامل عبر `api/confirm_sale_invoice.php`/`confirm_purchase_invoice.php`
حصراً). المسارات الفيزيائية بس تغيّرت (`retail1/api/...` بدل
`aleppo/api/...`).

---

## Features

لم يتغيّر أي feature وظيفياً بهالجلسة — الترحيل كان تسمية/بنية فقط، صفر
تغيير بالمنطق التجاري. راجع الجدول الأصلي بالتوثيق السابق لكل الميزات
المفعّلة (فوترة، مخزون، محاسبة، HR، باركود، طلبات داخلية...).

---

## Barcode Module (Generation & Scanning)

لم يتأثر بالترحيل — `inventory/barcode.php` (الآن بمسار
`retail1/modules/inventory/barcode.php`) ونفس منطق `generateFallbackBarcode()`
و`syncProductVariants()` بـ `includes/product_save_helper.php`.

---

## Purchase Invoice Currency-Mismatch Bug (fixed)

نفس الإصلاح الموثّق سابقاً — لم يتأثر بترحيل التسمية. الملف الآن بمسار
`retail1/modules/purchases/invoice_new.php` و`invoice_edit.php` بدل
`aleppo/...`.

---

## Consumables Module Findings — النتيجة النهائية (قسم مكتمل بالكامل)

> ⚠ **تصحيح مهم:** النقاط الموثّقة سابقاً هون (رقم ٢ و٥ تحديداً) أصبحت
> **قديمة/خاطئة** — "قيد الشراء لسا مفتوح" و"المناقلة لم تُبنَ بعد" —
> الاثنان **اكتملا فعلياً** بجلسة مخصصة كاملة لقسم "المصاريف والمستهلكات"
> (محادثة منفصلة طويلة، يوليو ٢٠٢٦). هاد القسم يوثّق **الحالة النهائية
> الفعلية** لكل شي، لا التسلسل التاريخي للتصحيحات.

### الصفحات السبع — كلها مكتملة

| الصفحة | المسار | الحالة |
|---|---|---|
| كتالوج المستهلكات | `expenses_and_consumables/consumables.php` | ✅ |
| فواتير الشراء | `expenses_and_consumables/consumable_purchases.php` | ✅ |
| أوامر الصرف | `expenses_and_consumables/consumable_issues.php` | ✅ |
| **المناقلة بين المستودعات** | `expenses_and_consumables/consumable_transfers.php` | ✅ **(ملف جديد بالكامل)** |
| إدارة المصاريف | `expenses_and_consumables/expenses.php` | ✅ |
| المستودعات (مشتركة مع المنتجات) | `inventory/warehouse.php` | ✅ |
| الحركات (مشتركة مع المنتجات) | `inventory/movements.php` | ✅ |

### جداول جديدة (نهائية)

- `consumable_categories_ret`, `consumable_units_ret`, `consumable_item_packagings_ret` — تصنيف/وحدات/عبوات ديناميكية (بدل enum ونص حر).
- `consumable_departments_ret` — الجهات المستلمة لأمر الصرف (بديل عن اقتراحات نصية ثابتة بالكود؛ مطابق لمفهوم Cost Center).
- `consumable_returns_ret` + `consumable_return_items_ret` — ميزة "إرجاع" مستقلة عن "الإلغاء" (كمية جزئية/كاملة من أمر صرف مؤكّد، قيد مستقل بسعر التكلفة الأصلي وقت الصرف).
- **`consumable_transfers_ret` + `consumable_transfer_items_ret` (جديدة بالكامل)** — مناقلة بين مستودعين، **بلا أي قيد محاسبي** (القيمة الإجمالية للمخزون ما بتتغيّر، بس توزيعها الفيزيائي). دورة حياة **مسودة → تأكيد** (عمود `status`)، مطابقة لمبدأ فاتورة الشراء بالضبط — الحفظ الأول بلا أثر فعلي، والتأكيد فقط ينفّذ الخصم/الإضافة الحقيقيين (بإعادة فحص الرصيد وقتها، لأنه ممكن يكون تغيّر منذ حفظ المسودة).

### أعمدة جديدة على جداول موجودة

- `consumable_items_ret.category_id`, `.unit_id` — الأعمدة النصية القديمة بقيت كأرشيف، غير مُستخدمة بالكود الحالي.
- `consumable_purchase_items_ret` / `consumable_issue_items_ret` / `consumable_transfer_items_ret` — كلهم عندهم `packaging_id`/`packaging_qty` (نفس النمط بالثلاثة: `quantity` دايماً بوحدة المخزون الأساسية، والعبوة للعرض/التدقيق بس).
- `consumable_issue_items_ret.returned_qty` — تتبّع تراكمي لمنع تجاوز الكمية الأصلية بالإرجاع.
- `expenses_ret.status`/`cancelled_at`/`cancelled_by` — "الحذف" بالواجهة صار "إلغاء" حقيقي (قيد عكسي + تحديث حالة)، مش `DELETE` فعلي كان يمحي القيد المحاسبي بالكامل (بق حرج، مُصلح).

### إصلاحات محاسبية جوهرية (على مستوى النظام، اكتُشفت هون أول مرة)

1. **`postAccountBalance()`** — دالة مشتركة (نفس النسخة بكل ملفات القسم) بترحّل فعلياً رصيد الحساب بشجرة الحسابات (`account_charts.balance`/`base_balance`) عند كل قيد — كانت القيود بتنكتب بدفتر اليومية بس، بدون أي تحديث فعلي على الرصيد المخزّن. **بق نظامي مؤكّد موجود على الأغلب بباقي الوحدات كمان (مبيعات، مشتريات منتجات، رواتب) — غير مفحوص هناك بعد.**
2. **`currency` (نص) → `currency_id` (FK رقمي)** بجدولي `journal_entries`/`journal_entry_items` — بُني ومُطبّق أول مرة هون (`resolveCurrencyId()`)، يستاهل تعميم على باقي ملفات النظام.
3. **`original_amount` منفصل عن `base_amount`** — كان بعض القيود بيكرر نفس الرقم بالعمودين (خطأ، المفروض `original_amount` بعملة المستند الأصلية).
4. **فصل ضريبة مشتريات المستهلكات كأصل منفصل (اختياري)** — مفتاح `tax_input_recoverable` بـ`invoice_account_settings`؛ حساب جديد `1.1.8` بشجرة الحسابات. اختياري حسب نظام كل فرع الضريبي (تركيا KDV قابلة للاسترداد، سوريا حالياً لأ).
5. **حسابات الدفع/الصندوق تُجلب من `invoice_account_settings` الفعلي** (`cash_*`/`bank_*`) — لا تخمين بنمط كود الحساب (كان بق حقيقي بـ`expenses.php`).
6. **فلترة حساب الدفع حسب العملة المختارة** — منع اختيار "صندوق ليرة سورية" مع عملة "دولار" بنفس المستند.

### مكوّنات UI/UX موحّدة عبر القسم كامل (تفصيل كامل بملف Blueprint منفصل)

- شريط تبويبات موحّد (٧ تبويبات) بكل الصفحات السبع، بما فيها الصفحات المشتركة (شرطياً حسب السياق).
- نظام ألوان ثابت بكل الجداول: أزرق=معرّف، أخضر=مصدر، أحمر=هدف، أصفر=كمية، أسود=قيمة مالية.
- فرز بالنقر على أي رأس عمود (دالة JS عامة مكرّرة بكل الملفات) — مع إصلاح بق فرز التواريخ (`parseFloat` كان يوقف عند أول شرطة بـ`YYYY-MM-DD`).
- إدراج بنود موحّد: سطر جديد فوق + تظليل مؤقت + تركيز تلقائي (بارامتر `isNew`).
- **مستند مرجعي كامل منفصل:** `blueprint-consumables-expenses-pattern.md` — يوثّق كل نمط معماري وتصميمي هون كـ"مخطط قابل لإعادة الاستخدام" لأي قسم جديد بالنظام (مبيعات، مشتريات منتجات...).

### إصلاحات بنيوية إضافية (بعد نقل المجلد لـ`expenses_and_consumables/`)

- روابط نسبية كتير انكسرت بعد النقل (كل ملف بحاجة مراجعة يدوية لعمق `../` الصحيح) — درس متكرر: **أي نقل ملف = مراجعة كل رابط نسبي جواه فوراً**.
- `sidebar.php::moduleUrl()` كانت ناقصة مفتاح `expenses.consumable_transfers` بالكامل (القائمة الجانبية كانت بترجع `#`).
- `warehouse.php` — بق صلاحية (فحص ثابت `inventory.warehouse` بغض النظر عن السياق، والفحص كان قبل تحديد السياق أصلاً — رُتّب وصار ديناميكي).
- `movements.php` — عمود الوحدة كان يقرا `ci.unit` (عمود نصي مجمّد قديم) بدل `unit_id`→`consumable_units`؛ وعمود "المرجع" كان يعرض `reference_type` الخام بالإنجليزي بدل ترجمة عربية.

### ⚠ لسا مفتوح (بقرار صريح، لمحادثات لاحقة)

- تعميم بق "ترحيل رصيد شجرة الحسابات" على باقي وحدات النظام.
- تعميم `currency`→`currency_id` على باقي ملفات النظام.
- آلية الدفع الفعلية (سند دفع مستقل، الزر جاهز بس الصفحة لأ).
- جهة الكتابة لأسعار الصرف المؤرخة (القراءة بس مبنية).
- توحيد نموذج بيانات المخزون (دمج `consumable_items`/`consumable_stock` مع `products`/`warehouse_items`) — بق معماري حقيقي موثّق، إعادة هيكلة واسعة مؤجّلة.

الجداول المعنية كلها بلاحقة `_ret` (كانت `_alp`)، بدون أي تغيير إضافي
بالمنطق غير المذكور أعلاه.

---

## Purchases Module (Invoices + Returns + Reports) — الحالة النهائية (قسم مكتمل بالكامل، يوليو ٢٠٢٦)

> محادثة مخصصة طويلة ومنفصلة (مستقلة عن جلسة المستهلكات). القسم مكتمل
> هيكلياً بالكامل — ٥ تبويبات: إدارة الموردين، فواتير المشتريات،
> مرتجعات المشتريات، أوامر الشراء (**بوضع صيانة مؤقت عمداً**)، التقارير.
> **المرجع الشامل الموحَّد لكل قرار وباگ هون:** `master-construction-blueprint.md`
> — يُقرأ بالكامل قبل بناء المبيعات، يحلّ محل الرجوع لملفي البلوبرينت
> القديمين منفصلين.

### الصفحات — كلها مكتملة وظيفياً

| الصفحة | المسار | الحالة |
|---|---|---|
| إدارة الموردين | `purchases/suppliers.php` | ✅ |
| فواتير الشراء (إنشاء) | `purchases/invoice_new.php` | ✅ |
| فواتير الشراء (قائمة + تأكيد) | `purchases/index.php` + `api/confirm_purchase_invoice.php` | ✅ |
| مرتجعات المشتريات | `purchases/returns.php` + `api/confirm_purchase_return.php` | ✅ مختبرة بنجاح |
| أوامر الشراء / RFQ | `purchases/orders.php` | ⚠ وضع صيانة مؤقت (نفس نمط `inventory.internal_orders`) — القرارات المعمارية جاهزة (مرحلة واحدة، مورد واحد، اعتماد→مسودة فاتورة تلقائياً)، البناء مؤجَّل |
| التقارير | `purchases/reports.php` | ✅ ٧ تقارير (سجل مشتريات، أكثر شراءً، مرتجعات، نسبة إرجاع، فرص خصم تعجيل، توزيع عملة، تاريخ سعر) |

### جداول/أعمدة جديدة

- `purchase_returns_ret` + `purchase_return_items_ret` — أُصلحت من سكيما قديمة ناقصة: `currency_id`/`base_currency_id` (FK بدل نص)، `refund_account_id`، `discount_amount`/`tax_amount` (متناسبين مع الفاتورة الأصلية).
- `purchases_ret.settlement_discount_pct` — خصم تعجيل الدفع، يُدخَل وقت الإنشاء، يُتحقَّق منه بالسيرفر حصراً وقت التأكيد.
- `branches.tax_input_recoverable` — نفس مفهوم المستهلكات (قسم ٤ فوق)، مُعمَّم هون كمان.
- حسابات فرعية مخصصة لكل مورد منتجات حقيقي (`ذمم {اسم المورد}`, `دفعات مقدمة — {اسم المورد}`) بدل حساب `200`/`1017` المشترك — **موردو المستهلكات لسا على الحساب المشترك، مؤجَّلين بقرار صريح لمحادثة المستهلكات**.
- حساب `خصم مشتريات تجاري مكتسب` (`4.2.1`) و`إيراد خصم تعجيل الدفع` (`4.2.2`) — منفصلان تماماً (تفاوض سعر مقابل سرعة سداد).
- `purchases_ret.currency` (عمود نصي قديم متروك، نفس فئة `branches.base_currency`) — **حُذف يدوياً من المستخدم بعد اكتشافه**؛ كل قراءة عملة صارت عبر `invoice_currency_id` FK حصراً.

### إصلاحات محاسبية جوهرية (اكتُشفت هون، أشدّها خطورة بالمشروع كله)

1. **🔴 اتجاه القيد مدين/دائن على حساب الالتزام (ذمم الموردين)** — كان الدفع الجزئي وخصم التعجيل والمرتجع الثلاثة ينسخون عامل الطرح من القيد الدائن الأصلي بدون عكسه، فتزيد المديونية المسجَّلة بدل ما تنقص. صُلح بثلاث ملفات (`confirm_purchase_invoice.php` مرتين، `confirm_purchase_return.php` مرة). **بيانات الاختبار المتراكمة قبل الإصلاح متأثرة، لم تُصفَّر بعد.**
2. **معادلة تحويل الدفع الجزئي** — كانت تخلط بين عملة المستند وعملة الفرع بخطوة وحدة ناقصة؛ صارت خطوتين، ثم بُسِّطت جذرياً بحصر خيارات عملة الدفع باثنين فقط (مستند/فرع) وفصل الحساب المحاسبي كلياً عن أي رقم قادم من الواجهة.
3. **تحويل الشحن بعملة ثالثة** — كان يُسجَّل بدون تحويل حقيقي (1:1 مع عملة الفرع)؛ صار عبر أولوية (عملة المستند نفسها → سعر المستند، عملة الفرع → 1، عملة ثالثة → حقل يدوي إلزامي بالسيرفر).
4. **`exchange_rate` مخزَّن على سطر القيد بمعنى غلط أكتر من مرة** (رقم وسيط منسوخ حرفياً بدل `original_amount ÷ base_amount` الفعلي).
5. **مسار `require_once` غلط بعدد مستويات `../`** بملف تأكيد المرتجعات (منسوخ من ملف بعمق مجلد مختلف) — درس: أي ملف جديد بمجلد `api/` يتأكد عمق مساراته يدوياً، لا نسخ أعمى.

### مكوّنات UI/UX جديدة تُضاف لبلوبرينت القسم العام

- كومبوبوكس مباشر لاختيار الفاتورة الأصلية بمودال المرتجع (بدل بحث+قائمة نقرية) — يُحمَّل تلقائياً بأحدث ١٥ فاتورة فور فتح المودال.
- زر اختصار "إنشاء مرتجع" مباشر من صف الفاتورة المؤكدة بجدول الفواتير (`?open_purchase_id=`).
- تشيك بوكس "تسوية فروقات التقريب الصغيرة" — اختياري، يتفعّل تلقائياً بس مع زر "دفع كامل بالخصم"، بحد أقصى ثابت `0.01$` بالسيرفر.
- مودال "تفاصيل التأكيد" مبني من `journal_entries` الفعلية المرتبطة (`reference_id`)، مع تحذير صريح لو مجموع البنود لا يطابق `total_amount` المخزَّن.

### ⚠ لسا مفتوح (بقرار صريح)

- موردو المستهلكات — نفس مشكلة الحساب المشترك، مؤجَّلة لمحادثة المستهلكات.
- تصفير أرصدة الاختبار المتراكمة بحسابات الموردين (تأثّرت بباگ اتجاه القيد قبل الإصلاح).
- أوامر الشراء/RFQ — بوضع صيانة، البناء الفعلي مؤجَّل.
- تنظيف كود ميت بسيط (`get_currency_rate` بالسيرفر — صار غير مُستخدم بعد تبسيط عملة الدفع، بس ما انحذف تفادياً لخطر تعديل سلسلة `if/elseif`).

---

> ⚠ **بعكس قسم المستهلكات أعلاه، هالقسم لسا غير مكتمل** — راجعنا صفحات
> "المخزون والمنتجات" (`inventory/`) بس، ولسا ما بلشنا مراجعة قسم
> المشتريات (`purchases/`) إطلاقاً، رغم إنه مرتبط عضوياً بنفس الجداول
> (`purchase_items_ret`/`purchases_ret`) يلي اكتشفنا بنيتها الحقيقية
> هالجلسة. مراجعة المشتريات محادثة منفصلة جاية.

### الصفحات الست المراجَعة

| الصفحة | المسار | الحالة |
|---|---|---|
| كتالوج المنتجات | `inventory/products.php` | ✅ بق جوهري مُصلح (تفصيل تحت) |
| إضافة منتج | `inventory/product_add.php` | ✅ بق اتجاه صفحة مُصلح |
| تعديل منتج | `inventory/product_edit.php` | ✅ رُوجعت آلية الحفظ (ألوان/قياسات/كروبات/متغيرات) — سليمة، بق بسيط واحد مُصلح |
| المستودعات (مشتركة مع المستهلكات) | `inventory/warehouse.php` | ✅ شريط تبويبات المنتجات الناقص أُضيف |
| الحركات (مشتركة مع المستهلكات) | `inventory/movements.php` | ✅ بق SQL جوهري + شريط تبويبات ناقص + رمز عملة ثابت — كلهم مُصلحين |
| الطلبات الداخلية | `inventory/internal_orders.php` | 🟡 **موقوفة عمداً (وضع صيانة)** — راجع تحت |

### الاكتشاف الجوهري: بنية `purchase_items_ret` الحقيقية مختلفة عمّا كان مفترضاً بكل الكود

عبر `DESCRIBE` فعلي (وليس تخمين)، تأكّد إنه `purchase_items_ret` **مُطبَّعة
(Normalized) بشكل صحيح** — فيها بس `product_id`/`variant_id` (أرقام
مرجعية)، **بدون** أي عمود نصي مجمّد (`product_name`, `model_number`,
`size`, `color`, `barcode`) ولا `warehouse_id`. هاد يخالف افتراض كان
مكرّراً بأكتر من ملف بالنظام (كود قديم كان يفترض وجود هالأعمدة مباشرة).

**بالمقابل**، `sales_invoice_items_ret` مصمَّمة عكسياً — **فيها فعلاً**
`item_name`/`model_number`/`size`/`color`/`barcode`/`warehouse_id` كأعمدة
مباشرة (تصميم denormalized مقصود على جانب المبيعات، مختلف عن جانب
المشتريات). **الاثنان تصميم صحيح بطريقتهم**، بس لازم أي كود يتعامل مع
الجانبين يفرّق بينهم صح، لا يفترض نفس البنية للاثنين.

`purchases_ret` (رأس الفاتورة) فيها `warehouse_id` (مش ببنودها)،
بالإضافة لـ`currency`/`exchange_rate`/`final_amount_base_currency`/
`invoice_currency_id`/`base_currency_id` و`status` بقيم
`draft/confirmed/received/cancelled`.

### تفاصيل الإصلاحات

1. **`products.php` — البق الجوهري (سبب "عدم ظهور الأسعار/القياسات"):**
   الاستعلام الرئيسي (يُنفَّذ لكل صف بالجدول) كان يذكر عمود `price_group`
   **غير موجود فعلياً بالجدول ولا يُملأ من `product_add.php`/`product_edit.php`
   إطلاقاً** — فكان يُسقط استثناء SQL بكل صف، يُبتلع بصمت
   (`catch (Exception $e)`)، فتطلع الأسعار/القياسات فاضية دايماً لكل
   منتج. أُزيل الاعتماد عليه نهائياً، والتجميع صار بالاعتماد على
   `selling_price`+`currency_id` (نفس المفتاح المستخدم أصلاً كـfallback
   بمكان تاني بالملف نفسه). كمان: عرض السعر تحسّن من "N أسعار" (عدّاد
   بس) لعرض **القيمة الفعلية أو المدى الكامل** (من-إلى) — أفيد فعلياً
   لصاحب القرار.
2. **`products.php` — فلترة المستودعات:** كانت تعرض كل المستودعات
   (بما فيها مستودع المستهلكات) بالقسم التحتاني؛ صارت تفلتر
   `WHERE warehouse_type='products'`.
3. **`products.php`/`warehouse.php`/`movements.php` — شريط تبويبات
   قسم المنتجات كان ناقصاً بالكامل** (موجود بس لسياق المستهلكات
   بالصفحتين المشتركتين، بدون `elseif` مقابل لسياق المنتجات). أُضيف
   بنفس الأسلوب البصري تماماً (المنتجات / المستودعات / حركة المخزون /
   الطلبات الداخلية).
4. **`products.php` — الجدول:** تحوّل لكلاس `mtbl` + فرز بالنقر على
   رأس العمود (دالة `sortTableByColumn()` جديدة، نفس منطق قسم
   المستهلكات: تاريخ ISO أولاً، رقم كامل المطابقة ثانياً، نص عربي
   أخيراً — بدون استخدام `parseFloat()` مباشرة على تاريخ).
5. **`product_add.php` — بق اتجاه الصفحة:** كانت `<html dir="ltr">`
   بدل `dir="rtl"` — الصفحة كاملة كانت ترتسم بالاتجاه المعكوس، عكس كل
   صفحات النظام (بما فيها `product_edit.php` نفسها).
6. **`product_edit.php` — مراجعة آلية الحفظ:** سليمة بمعظمها (بتستخدم
   `saveProductSizes()`/`syncProductVariants()` المشتركتين والمُصلحتين
   مسبقاً). بق واحد حقيقي: مفتاح الكروب الجديد كان يعتمد على `Date.now()`
   بس (احتمال تصادم نادر لو انضغط زر "إضافة كروب" مرتين بنفس اللحظة) —
   وُحّد مع الحل الأضمن الموجود أصلاً بـ`product_add.php` (عدّاد + وقت).
7. **`movements.php` — بق SQL جوهري (كان يطلّع الصفحة كاملة):**
   استعلام حركات الشراء كان يفترض أعمدة غير موجودة (`pi.product_name`
   وأخواتها، تفصيل أعلاه). أُعيد بناؤه بـJOIN حقيقي مع
   `products`/`product_variants`/`product_sizes`/`product_colors`،
   و`warehouse_id` صار يُقرأ من رأس الفاتورة (`purchases_ret`) لا من
   بنودها.
8. **`movements.php` — رمز عملة ثابت:** رمز `$` كان مكتوباً حرفياً
   بأربع أماكن (قسم الإحصائيات مرتين، جدول التفاصيل مرتين) — الملف ما
   كان فيه أصلاً استعلام لجلب عملة الفرع. أُضيف الاستعلام (نفس نمط
   `products.php`/`warehouse.php`) واستُبدلت الأماكن الأربعة.
9. **`internal_orders.php`:**
   - نفس بق أعمدة `purchase_items_ret` المفترضة خطأ كان موجوداً بدالة
     `convert_to_purchase` (INSERT بأعمدة `product_name`/`model_number`/
     `size`/`color`/`barcode` غير الموجودة) — أُصلح بنفس منطق `movements.php`.
   - أُضيف زر "ربط الفرع بمعمل" على تنبيه "الفرع غير مرتبط بمعمل"،
     بشرط `can('admin.branches', 'edit')` — ⚠ **مفتاح الصلاحية والمسار
     النسبي (`../admin/branches.php`) افتراض غير مؤكّد ١٠٠٪**، يحتاج
     تحقق مباشر من الملف الفعلي.
   - **بعدها بقرار صريح، الصفحة كاملة صارت بوضع "تحت الصيانة"** —
     خروج مبكر واحد (`if (true) {...صفحة تحت الصيانة...exit;}`) مباشرة
     بعد فحص الصلاحية، **بدون حذف أي سطر من الكود الأصلي تحته**. السبب:
     ربط فروع البيع بفروع التصنيع مالوش معنى فعلي لحد ما يُبنى قسم
     التصنيع بالكامل أولاً (قرار تسلسل عمل صريح، مو خطأ). لإعادة
     التفعيل: حذف بلوك `if (true)` المُعلَّق بوضوح بالكود.

### ⚠ لسا مفتوح (بقرار صريح، لمحادثات لاحقة)

- **مراجعة قسم المشتريات كاملة (`purchases/`)** — لسا ما بلشت، ومرتبطة
  مباشرة ببنية `purchase_items_ret`/`purchases_ret` المكتشَفة هالجلسة.
- تأكيد مفتاح صلاحية/مسار زر "ربط الفرع بمعمل" بـ`internal_orders.php`.
- تفعيل `internal_orders.php` بعد اكتمال قسم فروع التصنيع.
- تعميم فحص "رمز عملة ثابت" (`$` حرفية) على باقي ملفات النظام غير
  المفحوصة بعد — نفس نمط البق مذكور مسبقاً بقائمة Future Improvements
  العامة، بس الآن مؤكَّد فعلياً بملف حقيقي (`movements.php`) لا مجرد شك.

---

## Security Notes

| Severity | Issue | الحالة بعد الترحيل |
|---|---|---|
| 🔴 Critical | بيانات اتصال DB حرفية بالكود | لم تتغيّر — لسا موجودة بكلا نسختي `config/database.php` |
| 🔴 Critical | `reset_password.php` بدون مصادقة حقيقية | لم تتغيّر — لسا موجود، لازم يُحذف قبل أي إنتاج |
| 🔴 Critical | `hr/test_db.php` بيطبع `$_SESSION` كامل | لم يُراجع بعد هالترحيل — ⚠ تأكد مساره لسا صحيح تحت `retail1/` |
| 🟠 High | `payroll_api.php` بدون `requirePermission()` | لم تتغيّر |
| 🟠 High | `get_currencies.php` بدون auth | لم تتغيّر |
| 🟡 Medium | لا CSRF tokens بأي مكان | لم تتغيّر |
| 🟡 Medium | `dashboard.php` فحص `table_suffix==='ret'` ثابت — نفس نمط الضعف القديم بس بقيمة جديدة | **جديد بالتوثيق، قديم بالجوهر** — راجع Known Limitations |
| 🟢 جديد بهالجلسة | مسارات مطلقة `/bayhas/` كانت متناثرة بعشرات الأماكن — تم تجميعها بثابت `BASE_PATH` واحد | ✅ مُصلح على اللوكل، ⚠ Hostinger لسا |
| 🟡 Medium | `products.php`: `display_errors=1` مفعّل بالإنتاج | ✅ **مُصلح بهالجلسة** — صار `0` |

---

## Known Limitations

1. **فرع واحد فقط (`retail1/`, لاحقة `ret`) عنده كود شغّال** — باقي
   الفروع (Istanbul, Gaziantep, labs) schema-only بدون صفحات حقيقية.
2. **`dashboard.php` لسا بيفحص قيمة `table_suffix` ثابتة** (`'ret'` بدل
   `'alp'` القديمة) بدل التحقق من `branch_type==='retail'` ديناميكياً —
   لو انضاف فرع بيع تاني بالمستقبل، لازم هالفحص يتعمم أولاً.
3. **الجداول القديمة الميتة** (`employees_ret`, `attendance_ret`,
   `payroll_ret`, `consumables_ret`, `consumable_entries_ret`) لسا
   موجودة (اترحّلت اسمياً بس بقيت ميتة وظيفياً).
4. **نسخة Hostinger (الإنتاج) لسا بالكامل على البنية القديمة** — `bayhas/`،
   `aleppo/`، `_alp`، بدون `BASE_PATH`، بدون `tenant_resolver.php`. أي
   قرار نشر فعلي لازم ينتظر ترحيل كامل مطابق لنسخة اللوكل أولاً.
5. **لا تزال هناك احتمالية لمسارات `/bayhas/` متبقية غير مكتشفة** حتى
   على نسخة اللوكل — الجرد تم يدوياً عبر "Find in Files"، وهاي طريقة
   عرضة لتفويت أنماط غير متوقعة (مثل `$base = '/bayhas/'` يلي فات أول
   مرة). يُنصح بجرد آلي شامل (`grep -rn "bayhas" --include=*.php .`
   بدون أي شرط قبل/بعد) كخطوة تحقق أخيرة.
6. **مسار `admin/branches.php` بالتشجير أعلاه غير مؤكد ١٠٠٪** — ظهر
   بالتوثيق الأصلي تحت `admin/branches.php`، بس المحتوى الفعلي يلي
   عدّلناه أشار لمسار مشابه بقسم `accounting/` بنسخة قديمة من التوثيق؛
   يحتاج تأكيد مباشر من التشجير الفعلي بالسيرفر.
7. **لا CSRF، لا rate limiting، لا اختبارات آلية** — لم تتغيّر بهالجلسة.

---

## Future Improvements

- [ ] ترحيل نسخة Hostinger بالكامل لتطابق نسخة اللوكل (كل خطوات هالجلسة)
- [ ] تعميم فحص `dashboard.php` ليعتمد `branch_type` بدل `table_suffix` ثابت
- [ ] جرد آلي نهائي (`grep -rn "bayhas"`) على كلا البيئتين
- [ ] حذف الجداول الميتة القديمة (`employees_ret` وأخواتها) بعد تأكيد عدم استخدامها
- [ ] بناء وتفعيل باقي طبقة الـ SaaS (تسجيل تينانت جديد، تسجيل دخول فعلي عبر ساب-دومين حقيقي)
- [ ] حذف `reset_password.php`, `hr/test_db.php`, `api/test_api.php` قبل أي إنتاج حقيقي
- [ ] إضافة CSRF tokens
- [x] ~~ميزة نقل مستهلكات بين الفروع~~ — **بُنيت فعلاً، بس بنطاق مختلف عن الوصف الأصلي هون:** المبنية فعلياً هي **مناقلة بين مستودعين ضمن نفس الفرع** (`consumable_transfers.php`)، مش بين فروع مختلفة. جداول `consumable_transfers_ret`/`consumable_transfer_items_ret` (لا `from_branch_id`/`to_branch_id` — بس `from_warehouse_id`/`to_warehouse_id`)، دورة حياة مسودة→تأكيد، بلا أي قيد محاسبي (القيمة الإجمالية ما بتتغيّر). **"نقل بين فروع مختلفة" (لو احتيج لاحقاً) يضل مفهوم منفصل غير مبني** — يحتاج تصميم مختلف (فرعين = قاعدتي بيانات منفصلتين بالكامل، مش نفس الفرع).

- [ ] مراجعة `consumable_sale_items_ret`/`consumable_sales_ret` لاحقاً: حذف نهائي أم إبقاء schema-only كالجداول الميتة الأخرى (قرار غير مُتخذ بعد)
- [x] ~~جرد `_alp` شامل عبر كل المشروع~~ — **أُغلق: صفر نتائج بكل المشروع**
- [ ] **🆕 صفحة "إضافة فرع جديد"** — غير موجودة إطلاقاً بالمشروع؛ الفروع تُنشأ حالياً يدوياً عبر SQL مباشر. مؤجّلة لجلسة الإدارة والصلاحيات
- [ ] **🆕 تعميم `renderBreadcrumb()`** على باقي صفحات النظام — طُبّق بس على قسم المصاريف والمستهلكات لحد الآن
- [ ] **🆕 استخراج دوال JS الشريط الجانبي** (`toggleGroup`/`sbOpen`/`sbClose`) لملف مشترك واحد بدل تكرارها بكل صفحة — قرار معلّق، وفحص باقي الصفحات (~٢٤ ملف) لنفس بق `warehouse.php` (فُقدت منها هالدوال بالكامل) لسا جارٍ تدريجياً مع مراجعة كل قسم
- [ ] **🆕 ربط `consumable_item_packagings_ret`** (عبوات/عامل تحويل) بصفحة `consumable_issues.php` — غير موجود حالياً رغم وجوده ومفعّل بـ`consumable_purchases.php`
- [ ] **🆕 توحيد رمز العملة بالواجهة** — استبدال `$` الحرفية وفحوصات JS من نوع `=== 'USD'` بمنطق ديناميكي يعتمد عملة الفرع/التقارير الفعلية (راجع [Currency Architecture](#currency-architecture-july-2026--reporting-currency-reform))
- [ ] **🆕 حقل سعر صرف مستقل لتكلفة الشحن** بفاتورة شراء المنتجات — حالياً بدون تحويل حقيقي لو أُدخلت بعملة مختلفة عن عملة الفرع
- [ ] **🆕 حسم تضارب اتجاه سعر الصرف** بقيد ذمم العملاء (`confirm_sale_invoice.php`) — يحتاج جلسة محاسبة مخصصة

---

## Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| صفحة بيضاء تماماً | افتح `logs/php-error.log` — `display_errors` مطفي بشكل متعمد بأغلب الملفات |
| "Branch not supported" / إعادة توجيه من الداشبورد | `dashboard.php` بيقبل بس `table_suffix === 'ret'` حالياً |
| روابط/صور مكسورة (404) بعد أي رينيم مستقبلي | دوّر عن `/bayhas/` أو أي مسار مطلق قديم لم يُستبدل بـ `BASE_PATH` |
| سلوك مختلف بين اللوكل و Hostinger | متوقّع حالياً — البيئتين غير متطابقتين بعد، راجع [Deployment Environments](#deployment-environments) |

---

## Development Guidelines

### قاعدة تسمية الجداول
```php
$table = "products_{$TS}";  // استخدم $_SESSION['table_suffix'] دائماً، لا تكتب "_ret" حرفياً بأي مكان
```

### قاعدة المسارات المطلقة
```php
// ممنوع:
header('Location: /fatorize_erp_system/select_account.php');

// صح:
header('Location: ' . BASE_PATH . '/select_account.php');
```

### إضافة صفحة جديدة
نفس الخطوات الموثّقة سابقاً، بس تأكد أي مسار مطلق جديد تكتبه يستخدم
`BASE_PATH` من أول يوم، ما تكتب `/fatorize_erp_system/` أو `/bayhas/`
حرفياً بأي مكان جديد.

---

*هالنسخة من التوثيق محدّثة حتى نهاية جلسة مراجعة قسم "المخزون والمنتجات"
(يوليو ٢٠٢٦) — راجع [Inventory & Products Module Findings](#inventory--products-module-findings--تقدّم-الجلسة-الحالية-غير-مكتمل)
لتفاصيل هالجلسة (**غير مكتملة** — قسم المشتريات لسا ما راجعناه، محادثة
منفصلة جاية). راجع كمان [Consumables Module Findings](#consumables-module-findings--النتيجة-النهائية-قسم-مكتمل-بالكامل)
(القسم هذا مكتمل ١٠٠٪)، [Sidebar/Menu Restructuring](#sidebarmenu-restructuring--shared-components-july-2026)
لتفاصيل جلسة الشريط الجانبي، [Currency Architecture](#currency-architecture-july-2026--reporting-currency-reform)
لجلسة العملات، و[Migration Log](#migration-log-july-2026--generic-branchtenant-naming)
لجلسة الترحيل البنيوي الأولى. أي قسم غير مذكور تفصيلياً هون (Features
الكاملة، الـ ERD، الجداول التفصيلية بالأعمدة) لم يتغيّر عن التوثيق
الأصلي ولسا صالح كما هو.*
