<?php
/**
 * super_admin/add_tenant.php
 * أداة داخلية (لصاحب منصة فاتورايز فقط، مش لأي عميل/tenant) لتسجيل
 * شركة جديدة بالسجل المركزي بعد ما تكون أنشأت قاعدة بياناتها يدوياً
 * وعبّيتها بالسكيما (u987540206_bayhas.sql) عبر hPanel/phpMyAdmin.
 *
 * ⚠ هذا الملف حسّاس جداً — أي شخص يوصله فيه يقدر يسجّل/يشوف بيانات
 * اتصال قواعد بيانات كل عملائك. الحماية الحالية (كلمة مرور واحدة
 * ثابتة) هي حد أدنى مؤقت فقط. يُنصح بشدة أيضاً بحصر الوصول لهذا
 * المجلد بعنوان IP معيّن (عبر .htaccess) بالإضافة لكلمة المرور.
 */

session_start();
require_once __DIR__ . '/../config/master_database.php';

// ─────────────────────────────────────────────────────────────
// كلمة مرور دخول بسيطة لهذه الأداة فقط — غيّرها فوراً قبل الاستخدام
// لتوليد hash جديد: php -r "echo password_hash('كلمة_مرورك', PASSWORD_DEFAULT);"
// ─────────────────────────────────────────────────────────────
if (!defined('SUPER_ADMIN_PASSWORD_HASH')) {
    define('SUPER_ADMIN_PASSWORD_HASH', '$2y$10$CHANGE.ME.THIS.IS.NOT.A.REAL.HASH.REPLACE.BEFORE.USE');
}

$loggedIn = !empty($_SESSION['super_admin_ok']);

if (isset($_POST['_login'])) {
    if (password_verify((string)($_POST['admin_password'] ?? ''), SUPER_ADMIN_PASSWORD_HASH)) {
        $_SESSION['super_admin_ok'] = true;
        $loggedIn = true;
    } else {
        $loginError = 'كلمة مرور خاطئة';
    }
}

if (!$loggedIn) {
    ?>
    <!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8">
    <title>دخول لوحة إدارة المنصة</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    </head><body class="bg-light">
    <div class="container" style="max-width:380px;margin-top:15vh">
        <h5 class="mb-3">دخول لوحة إدارة المنصة</h5>
        <?php if (!empty($loginError)): ?><div class="alert alert-danger"><?= htmlspecialchars($loginError) ?></div><?php endif; ?>
        <form method="POST">
            <input type="hidden" name="_login" value="1">
            <input type="password" name="admin_password" class="form-control mb-2" placeholder="كلمة المرور" required autofocus>
            <button class="btn btn-primary w-100">دخول</button>
        </form>
    </div></body></html>
    <?php
    exit;
}

$pdo = getMasterConnection();
$message = '';
$messageType = 'success';

// ─────────────────────────────────────────────────────────────
// معالجة إضافة عميل جديد
// ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['_action']) && $_POST['_action'] === 'add_tenant') {
    try {
        $companyName = trim($_POST['company_name'] ?? '');
        $subdomain   = strtolower(trim($_POST['subdomain'] ?? ''));
        $tenantType  = $_POST['tenant_type'] ?? 'shop';
        $dbHost      = trim($_POST['db_host'] ?? 'localhost');
        $dbName      = trim($_POST['db_name'] ?? '');
        $dbUser      = trim($_POST['db_user'] ?? '');
        $dbPass      = (string)($_POST['db_pass'] ?? '');
        $plan        = trim($_POST['plan'] ?? 'basic');
        $status      = $_POST['status'] ?? 'trial';

        if ($companyName === '' || $subdomain === '' || $dbName === '' || $dbUser === '' || $dbPass === '') {
            throw new Exception('يرجى تعبئة كل الحقول المطلوبة');
        }
        if (!preg_match('/^[a-z0-9-]{2,63}$/', $subdomain)) {
            throw new Exception('الساب دومين يجب أن يحتوي أحرف إنجليزية صغيرة/أرقام/شرطة فقط');
        }

        // تأكد عدم تكرار الساب دومين
        $chk = $pdo->prepare('SELECT COUNT(*) FROM tenants WHERE subdomain = ?');
        $chk->execute([$subdomain]);
        if ((int)$chk->fetchColumn() > 0) {
            throw new Exception("الساب دومين \"{$subdomain}\" مستخدم مسبقاً");
        }

        // تحقق فعلي: هل بيانات الاتصال هاي شغالة ووصلت فعلاً لقاعدة العميل؟
        try {
            $testDsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
            $testPdo = new PDO($testDsn, $dbUser, $dbPass, [PDO::ATTR_TIMEOUT => 5]);
            $tableCount = (int)$testPdo->query("SHOW TABLES")->rowCount();
            if ($tableCount < 10) {
                throw new Exception("الاتصال نجح لكن القاعدة فيها {$tableCount} جدول فقط — تأكد إنك استوردت السكيما الكاملة (u987540206_bayhas.sql) فيها قبل ما تضيفها هون");
            }
        } catch (PDOException $e) {
            throw new Exception('تعذّر الاتصال بقاعدة بيانات العميل بهاي البيانات — تأكد من إنشائها واستيراد السكيما فيها أولاً. تفاصيل: ' . $e->getMessage());
        }

        $dbPassEnc = encryptSecret($dbPass);

        $ins = $pdo->prepare("INSERT INTO tenants
            (company_name, subdomain, tenant_type, db_host, db_name, db_user, db_pass_enc, status, plan)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $ins->execute([$companyName, $subdomain, $tenantType, $dbHost, $dbName, $dbUser, $dbPassEnc, $status, $plan]);

        $message = "تمت إضافة الشركة \"{$companyName}\" بنجاح — بيوصلها المستخدمين عبر: {$subdomain}." . PLATFORM_BASE_DOMAIN;
    } catch (Exception $e) {
        $message = $e->getMessage();
        $messageType = 'danger';
    }
}

$tenants = $pdo->query("SELECT id, company_name, subdomain, tenant_type, status, plan, created_at FROM tenants ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>إدارة عملاء المنصة — Fatorize</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
<style>body{font-family:sans-serif;background:#f8fafc}</style>
</head>
<body class="p-4">
<div class="container" style="max-width:900px">
    <h4 class="mb-4">إدارة عملاء منصة فاتورايز</h4>

    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">إضافة شركة (tenant) جديدة</div>
        <div class="card-body">
            <p class="text-muted small">
                ⚠ قبل تعبئة هذا النموذج: أنشئ قاعدة بيانات جديدة يدوياً عبر hPanel،
                واستورد فيها ملف <code>u987540206_bayhas.sql</code> كاملاً عبر phpMyAdmin.
                هذا النموذج فقط <strong>يسجّل</strong> شركة جاهزة، لا ينشئها.
            </p>
            <form method="POST" class="row g-3">
                <input type="hidden" name="_action" value="add_tenant">
                <div class="col-md-6">
                    <label class="form-label">اسم الشركة</label>
                    <input type="text" name="company_name" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">الساب دومين (أحرف إنجليزية صغيرة فقط)</label>
                    <div class="input-group">
                        <input type="text" name="subdomain" class="form-control" required pattern="[a-z0-9-]+">
                        <span class="input-group-text">.fatorize.com</span>
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">نوع النشاط</label>
                    <select name="tenant_type" class="form-select">
                        <option value="shop">محل/مبيعات</option>
                        <option value="factory">مصنع</option>
                        <option value="both">الاثنين (مصنع + مبيعات)</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">الخطة</label>
                    <select name="plan" class="form-select">
                        <option value="basic">Basic</option>
                        <option value="pro">Pro</option>
                        <option value="enterprise">Enterprise</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">الحالة</label>
                    <select name="status" class="form-select">
                        <option value="trial">تجريبي</option>
                        <option value="active">نشط</option>
                    </select>
                </div>
                <hr class="mt-4">
                <div class="col-md-4">
                    <label class="form-label">DB Host</label>
                    <input type="text" name="db_host" class="form-control" value="localhost" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">DB Name</label>
                    <input type="text" name="db_name" class="form-control" required placeholder="u987540206_xxxxx">
                </div>
                <div class="col-md-4">
                    <label class="form-label">DB User</label>
                    <input type="text" name="db_user" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">DB Password</label>
                    <input type="password" name="db_pass" class="form-control" required>
                </div>
                <div class="col-12">
                    <button class="btn btn-primary">إضافة الشركة</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">الشركات الحالية (<?= count($tenants) ?>)</div>
        <table class="table mb-0">
            <thead><tr><th>الاسم</th><th>الساب دومين</th><th>النوع</th><th>الحالة</th><th>الخطة</th><th>تاريخ الإضافة</th></tr></thead>
            <tbody>
            <?php foreach ($tenants as $t): ?>
                <tr>
                    <td><?= htmlspecialchars($t['company_name']) ?></td>
                    <td dir="ltr"><?= htmlspecialchars($t['subdomain']) ?>.fatorize.com</td>
                    <td><?= htmlspecialchars($t['tenant_type']) ?></td>
                    <td><span class="badge bg-<?= $t['status'] === 'active' ? 'success' : ($t['status'] === 'trial' ? 'warning' : 'secondary') ?>"><?= htmlspecialchars($t['status']) ?></span></td>
                    <td><?= htmlspecialchars($t['plan']) ?></td>
                    <td><?= htmlspecialchars($t['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
