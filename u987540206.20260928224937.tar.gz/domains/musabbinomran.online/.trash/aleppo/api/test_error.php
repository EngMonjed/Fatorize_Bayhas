<?php
ini_set('display_errors',1);
error_reporting(E_ALL);
session_start();
require_once __DIR__.'/../../config/database.php';
$pdo=getConnection();
$TS=$_SESSION['table_suffix']??'alp';

// فحص أعمدة purchases
$cols=$pdo->query("SHOW COLUMNS FROM `purchases_{$TS}`")->fetchAll(PDO::FETCH_COLUMN);
echo json_encode(['columns'=>$cols],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);